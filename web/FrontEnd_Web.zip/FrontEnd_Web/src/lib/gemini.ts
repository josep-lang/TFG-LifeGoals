const API_KEY = import.meta.env.VITE_GEMINI_API_KEY || "";
const API_URL = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${API_KEY}`;

export async function generateMilestones(titulo: string, descripcion: string, categoria: string, fechaLimite?: string): Promise<string[]> {
  console.log("[IA] Generando hitos para:", titulo);

  if (!API_KEY) {
    console.error("❌ ERROR: VITE_GEMINI_API_KEY no está configurada.");
    return hitosGenericos(titulo);
  }

  try {
    const prompt = `Eres un coach de productividad experto.
Divide este objetivo en exactamente 7 hitos concretos y accionables.

OBJETIVO: "${titulo}"
DESCRIPCIÓN: "${descripcion || "Sin descripción"}"
CATEGORÍA: "${categoria}"
FECHA LÍMITE: ${fechaLimite || "Sin fecha"}

IMPORTANTE:
Responde SOLO con un array JSON.
No añadas texto antes ni después.
No uses markdown.

Formato exacto:
["Hito uno", "Hito dos", "Hito tres", "Hito cuatro", "Hito cinco", "Hito seis", "Hito siete"]`;

    const response = await fetch(API_URL, {
      method: "POST",
      headers: { 
        "Content-Type": "application/json" 
      },
      body: JSON.stringify({
        contents: [
          {
            parts: [
              {
                text: prompt
              }
            ]
          }
        ],
        generationConfig: {
          temperature: 0.7,
          maxOutputTokens: 2056,
        },
      }),
    });

    const data = await response.json();

    console.log("[IA] Estado HTTP:", response.status);

    if (!response.ok || data.error) {
      throw new Error(data.error?.message || `HTTP ${response.status}`);
    }

    const rawText = data.candidates?.[0]?.content?.parts?.[0]?.text?.trim();
    console.log("[IA] Texto recibido:", rawText);

    if (!rawText) {
      throw new Error("Respuesta vacía");
    }

    // Extraer el array JSON de la respuesta
    const jsonMatch = rawText.match(/\[[\s\S]*?\]/);

    if (!jsonMatch) {
      throw new Error("No se encontró ningún JSON en la respuesta: " + rawText);
    }

    const hitos = JSON.parse(jsonMatch[0]);

    if (!Array.isArray(hitos) || hitos.length === 0) {
      throw new Error("El array recibido no es válido o está vacío");
    }

    console.log("[IA] Hitos generados correctamente:", hitos);

    return hitos;
  } catch (error: any) {
    console.error("[IA] Error:", error?.message ?? String(error));
    return hitosGenericos(titulo);
  }
}

function hitosGenericos(titulo: string) {
  return [
    `Definir el plan de acción para: ${titulo}`,
    "Identificar y conseguir los recursos necesarios",
    "Ejecutar la primera fase del plan",
    "Revisar el progreso y ajustar la estrategia",
    "Realizar seguimiento de los avances semanales",
    "Superar los obstáculos principales identificados",
    "Completar y consolidar el objetivo final",
  ];
}
