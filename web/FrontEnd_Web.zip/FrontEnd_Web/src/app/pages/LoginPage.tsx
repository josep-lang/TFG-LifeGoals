import React, { useState } from "react";
import { useNavigate } from "react-router";
import { motion, AnimatePresence } from "motion/react";
import { useGoals } from "../context/GoalsContext";
import { Eye, EyeOff, Waves, Target } from "lucide-react";

export default function LoginPage() {
  const { login, register } = useGoals();
  const navigate = useNavigate();
  const [isRegister, setIsRegister] = useState(false);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPass, setShowPass] = useState(false);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    await new Promise((r) => setTimeout(r, 600));
    
    let ok = false;
    try {
      if (isRegister) {
        if (!name.trim()) {
          setError("Por favor, ingresa tu nombre.");
          setLoading(false);
          return;
        }
        ok = await register(email, password, name);
      } else {
        ok = await login(email, password);
      }

      if (ok) {
        navigate("/dashboard");
      } else {
        setError(isRegister ? "Error al crear la cuenta. Inténtalo de nuevo." : "Error al iniciar sesión. Verifica tus credenciales.");
      }
    } catch (err) {
      setError("Ocurrió un error inesperado.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center relative overflow-hidden"
      style={{ background: "linear-gradient(135deg, #0ea5e9 0%, #06b6d4 40%, #0891b2 70%, #0e7490 100%)" }}>
      {/* Animated blobs */}
      <div className="absolute top-[-80px] left-[-80px] w-80 h-80 rounded-full opacity-20"
        style={{ background: "radial-gradient(circle, #7dd3fc, transparent)" }} />
      <div className="absolute bottom-[-60px] right-[-60px] w-96 h-96 rounded-full opacity-20"
        style={{ background: "radial-gradient(circle, #a5f3fc, transparent)" }} />
      <div className="absolute top-1/3 right-[-100px] w-64 h-64 rounded-full opacity-10"
        style={{ background: "radial-gradient(circle, #bae6fd, transparent)" }} />

      {/* Wave bottom decoration */}
      <svg className="absolute bottom-0 left-0 w-full" viewBox="0 0 1440 120" fill="none"
        xmlns="http://www.w3.org/2000/svg">
        <path d="M0 60 C360 120 1080 0 1440 60 L1440 120 L0 120 Z"
          fill="rgba(255,255,255,0.08)" />
        <path d="M0 80 C400 20 1000 140 1440 80 L1440 120 L0 120 Z"
          fill="rgba(255,255,255,0.05)" />
      </svg>

      <motion.div
        initial={{ opacity: 0, y: 30, scale: 0.97 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ duration: 0.5, ease: "easeOut" }}
        className="relative z-10 w-full max-w-sm mx-4"
      >
        <div className="rounded-3xl shadow-2xl overflow-hidden"
          style={{ background: "rgba(255,255,255,0.15)", backdropFilter: "blur(20px)", border: "1px solid rgba(255,255,255,0.25)" }}>
          {/* Header */}
          <div className="px-8 pt-10 pb-6 text-center">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl mb-4"
              style={{ background: "rgba(255,255,255,0.25)" }}>
              <Target className="text-white" size={32} />
            </div>
            <h1 className="text-white" style={{ fontSize: "1.75rem", fontWeight: 700 }}>
              LifeGoals
            </h1>
            <p className="mt-1" style={{ color: "rgba(255,255,255,0.75)", fontSize: "0.95rem" }}>
              {isRegister ? "Crea tu cuenta para empezar" : "Inicia sesión para ver tus metas"}
            </p>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="px-8 pb-10 space-y-4">
            <AnimatePresence mode="wait">
              {isRegister && (
                <motion.div
                  key="name-field"
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  exit={{ opacity: 0, height: 0 }}
                  transition={{ duration: 0.2 }}
                >
                  <label className="block mb-1.5" style={{ color: "rgba(255,255,255,0.85)", fontSize: "0.875rem" }}>
                    Nombre completo
                  </label>
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Tu nombre"
                    required={isRegister}
                    className="w-full px-4 py-3 rounded-xl outline-none transition-all"
                    style={{
                      background: "rgba(255,255,255,0.18)",
                      border: "1px solid rgba(255,255,255,0.3)",
                      color: "white",
                      fontSize: "0.95rem",
                    }}
                    onFocus={(e) => (e.target.style.border = "1px solid rgba(255,255,255,0.7)")}
                    onBlur={(e) => (e.target.style.border = "1px solid rgba(255,255,255,0.3)")}
                  />
                </motion.div>
              )}
            </AnimatePresence>

            <div>
              <label className="block mb-1.5" style={{ color: "rgba(255,255,255,0.85)", fontSize: "0.875rem" }}>
                Correo electrónico
              </label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="tu@correo.com"
                required
                className="w-full px-4 py-3 rounded-xl outline-none transition-all"
                style={{
                  background: "rgba(255,255,255,0.18)",
                  border: "1px solid rgba(255,255,255,0.3)",
                  color: "white",
                  fontSize: "0.95rem",
                }}
                onFocus={(e) => (e.target.style.border = "1px solid rgba(255,255,255,0.7)")}
                onBlur={(e) => (e.target.style.border = "1px solid rgba(255,255,255,0.3)")}
              />
            </div>

            <div>
              <label className="block mb-1.5" style={{ color: "rgba(255,255,255,0.85)", fontSize: "0.875rem" }}>
                Contraseña
              </label>
              <div className="relative">
                <input
                  type={showPass ? "text" : "password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  required
                  className="w-full px-4 py-3 pr-12 rounded-xl outline-none transition-all"
                  style={{
                    background: "rgba(255,255,255,0.18)",
                    border: "1px solid rgba(255,255,255,0.3)",
                    color: "white",
                    fontSize: "0.95rem",
                  }}
                  onFocus={(e) => (e.target.style.border = "1px solid rgba(255,255,255,0.7)")}
                  onBlur={(e) => (e.target.style.border = "1px solid rgba(255,255,255,0.3)")}
                />
                <button
                  type="button"
                  onClick={() => setShowPass(!showPass)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 p-1"
                  style={{ color: "rgba(255,255,255,0.6)" }}
                >
                  {showPass ? <EyeOff size={18} /> : <Eye size={18} />}
                </button>
              </div>
            </div>

            {error && (
              <motion.p
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="text-center rounded-lg py-2 px-3"
                style={{ background: "rgba(239,68,68,0.25)", color: "#fecaca", fontSize: "0.85rem" }}
              >
                {error}
              </motion.p>
            )}

            <motion.button
              type="submit"
              disabled={loading}
              whileTap={{ scale: 0.97 }}
              className="w-full py-3.5 rounded-xl transition-all mt-2"
              style={{
                background: loading ? "rgba(255,255,255,0.2)" : "rgba(255,255,255,0.95)",
                color: "#0891b2",
                fontWeight: 700,
                fontSize: "1rem",
                cursor: loading ? "not-allowed" : "pointer",
              }}
            >
              {loading ? (isRegister ? "Creando..." : "Entrando...") : (isRegister ? "Crear cuenta" : "Iniciar sesión")}
            </motion.button>

            <div className="flex items-center gap-3 my-2">
              <div className="flex-1 h-px" style={{ background: "rgba(255,255,255,0.2)" }} />
              <span style={{ color: "rgba(255,255,255,0.5)", fontSize: "0.8rem" }}>o</span>
              <div className="flex-1 h-px" style={{ background: "rgba(255,255,255,0.2)" }} />
            </div>

            <button
              type="button"
              onClick={() => {
                setIsRegister(!isRegister);
                setError("");
              }}
              className="w-full py-2 text-white hover:underline transition-all"
              style={{ fontSize: "0.9rem", fontWeight: 500 }}
            >
              {isRegister ? "¿Ya tienes cuenta? Inicia sesión" : "¿No tienes cuenta? Regístrate gratis"}
            </button>
          </form>
        </div>

        <div className="flex items-center justify-center gap-2 mt-6" style={{ color: "rgba(255,255,255,0.5)", fontSize: "0.8rem" }}>
          <Waves size={14} />
          <span>LifeGoals © 2026</span>
        </div>
      </motion.div>
    </div>
  );
}