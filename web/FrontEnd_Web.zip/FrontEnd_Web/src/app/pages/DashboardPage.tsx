import React, { useState } from "react";
import { useNavigate } from "react-router";
import { motion, AnimatePresence } from "motion/react";
import { useGoals } from "../context/GoalsContext";
import {
  Target, Plus, Dumbbell, DollarSign, BookOpen, Briefcase, Leaf,
  CheckCircle2, Trophy, Sparkles, Plane, Heart, User, GraduationCap
} from "lucide-react";

import { StatCard } from "../components/dashboard/StatCard";
import { GoalListItem } from "../components/dashboard/GoalListItem";
import { GoalDetailView } from "../components/dashboard/GoalDetailView";
import { ConfirmDeleteModal } from "../components/dashboard/ConfirmDeleteModal";

const categoryIcons: Record<string, React.ReactNode> = {
  Salud: <Heart size={18} />,
  Viajes: <Plane size={18} />,
  Finanzas: <DollarSign size={18} />,
  Personal: <User size={18} />,
  Aprendizaje: <GraduationCap size={18} />,
};

const categoryColors: Record<string, { main: string; light: string; text: string }> = {
  Salud:       { main: "#06b6d4", light: "#ecfeff", text: "#0891b2" },
  Viajes:      { main: "#0ea5e9", light: "#f0f9ff", text: "#0369a1" },
  Finanzas:    { main: "#0891b2", light: "#e0f7fa", text: "#0e7490" },
  Personal:    { main: "#0e7490", light: "#cffafe", text: "#155e75" },
  Aprendizaje: { main: "#22d3ee", light: "#f0fdff", text: "#0891b2" },
};

function formatDeadline(date: string) {
  if (!date) return "";
  const d = new Date(date + "T00:00:00");
  return d.toLocaleDateString("es-ES", { day: "2-digit", month: "short", year: "numeric" });
}

function daysLeft(deadline: string) {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const end = new Date(deadline + "T00:00:00");
  const diff = Math.ceil((end.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
  return diff;
}

export default function DashboardPage() {
  const {
    goals,
    selectedGoalId,
    setSelectedGoalId,
    addMilestone,
    toggleMilestone,
    deleteMilestone,
    deleteGoal,
    user
  } = useGoals();
  const navigate = useNavigate();
  const [confirmDelete, setConfirmDelete] = useState<string | null>(null);

  const selectedGoal = goals.find((g) => g.id === selectedGoalId) || null;

  const getProgress = (g: typeof goals[0]) => {
    if (g.milestones.length === 0) return 0;
    return Math.round((g.milestones.filter((m) => m.completed).length / g.milestones.length) * 100);
  };

  const handleDeleteGoal = async (goalId: string) => {
    await deleteGoal(goalId);
    setConfirmDelete(null);
    setSelectedGoalId(null);
  };

  // ─── Detail View ────────────────────────────────────────────────────────
  if (selectedGoal) {
    return (
      <>
        <GoalDetailView
          goal={selectedGoal}
          onBack={() => setSelectedGoalId(null)}
          onDeleteRequest={() => setConfirmDelete(selectedGoal.id)}
          onToggleMilestone={async (mid) => await toggleMilestone(selectedGoal.id, mid)}
          onDeleteMilestone={async (mid) => await deleteMilestone(selectedGoal.id, mid)}
          onAddMilestone={async (text) => await addMilestone(selectedGoal.id, text)}
          categoryIcon={categoryIcons[selectedGoal.category] || <Target size={18} />}
          categoryColor={categoryColors[selectedGoal.category] || categoryColors.fitness}
          formatDeadline={formatDeadline}
          daysLeft={daysLeft}
          progress={getProgress(selectedGoal)}
        />

        <AnimatePresence>
          {confirmDelete && (
            <ConfirmDeleteModal
              onConfirm={() => handleDeleteGoal(confirmDelete)}
              onCancel={() => setConfirmDelete(null)}
            />
          )}
        </AnimatePresence>
      </>
    );
  }

  // ─── Overview ───────────────────────────────────────────────────────────
  const totalMilestones = goals.reduce((acc, g) => acc + g.milestones.length, 0);
  const completedMilestones = goals.reduce((acc, g) => acc + g.milestones.filter((m) => m.completed).length, 0);
  const completedGoals = goals.filter((g) => g.milestones.length > 0 && getProgress(g) === 100).length;

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.4 }}>
      <div className="mb-6">
        <h1 style={{ color: "#0e7490" }}>¡Hola, {user?.name || "Explorador"} 👋</h1>
        <p style={{ color: "#0891b2", fontSize: "0.95rem" }}>
          Revisa tus metas y sigue avanzando hacia el éxito
        </p>
      </div>

      <div className="grid grid-cols-3 gap-3 mb-6">
        <StatCard label="Metas" value={goals.length} icon={<Target size={18} />} color="#0ea5e9" />
        <StatCard
          label="Hitos completados"
          value={`${completedMilestones}/${totalMilestones}`}
          icon={<CheckCircle2 size={18} />}
          color="#06b6d4"
        />
        <StatCard label="Metas logradas" value={completedGoals} icon={<Trophy size={18} />} color="#0891b2" />
      </div>

      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <Sparkles size={16} style={{ color: "#0891b2" }} />
          <span style={{ color: "#0e7490", fontWeight: 700 }}>Mis Metas</span>
        </div>
        <motion.button
          whileTap={{ scale: 0.94 }}
          onClick={() => navigate("/create")}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl"
          style={{
            background: "linear-gradient(135deg, #0ea5e9, #06b6d4)",
            color: "white",
            fontSize: "0.8rem",
          }}
        >
          <Plus size={13} />
          Nueva meta
        </motion.button>
      </div>

      {goals.length === 0 ? (
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          className="rounded-2xl p-10 text-center"
          style={{
            background: "rgba(255,255,255,0.85)",
            backdropFilter: "blur(12px)",
            border: "1px dashed rgba(14,165,233,0.3)",
          }}
        >
          <div className="w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-4"
            style={{ background: "linear-gradient(135deg, #e0f7fa, #cffafe)" }}>
            <Target size={28} style={{ color: "#0891b2" }} />
          </div>
          <h3 style={{ color: "#0e7490" }}>Aún no tienes metas</h3>
          <p className="mt-1 mb-5" style={{ color: "#94a3b8", fontSize: "0.875rem" }}>
            ¡Crea tu primera meta y comienza tu viaje hacia el éxito!
          </p>
          <motion.button
            whileTap={{ scale: 0.96 }}
            onClick={() => navigate("/create")}
            className="px-6 py-3 rounded-xl flex items-center gap-2 mx-auto"
            style={{
              background: "linear-gradient(135deg, #0ea5e9, #06b6d4)",
              color: "white",
              fontWeight: 700,
              boxShadow: "0 4px 16px rgba(14,165,233,0.35)",
            }}
          >
            <Plus size={18} />
            Crear primera meta
          </motion.button>
        </motion.div>
      ) : (
        <div className="space-y-3">
          {goals.map((goal, idx) => (
            <GoalListItem
              key={goal.id}
              goal={goal}
              pct={getProgress(goal)}
              col={categoryColors[goal.category] || categoryColors.fitness}
              days={daysLeft(goal.deadline)}
              formatDeadline={formatDeadline}
              onClick={() => setSelectedGoalId(goal.id)}
              categoryIcon={categoryIcons[goal.category] || <Target size={18} />}
              delay={idx * 0.06}
            />
          ))}
        </div>
      )}

      {goals.length > 0 && (
        <motion.button
          whileTap={{ scale: 0.97 }}
          onClick={() => navigate("/create")}
          className="w-full mt-4 py-3.5 rounded-2xl flex items-center justify-center gap-2 transition-all"
          style={{
            background: "rgba(255,255,255,0.6)",
            border: "2px dashed rgba(14,165,233,0.3)",
            color: "#0891b2",
            fontSize: "0.875rem",
          }}
          onMouseEnter={(e) => ((e.currentTarget as HTMLButtonElement).style.background = "rgba(14,165,233,0.08)")}
          onMouseLeave={(e) => ((e.currentTarget as HTMLButtonElement).style.background = "rgba(255,255,255,0.6)")}
        >
          <Plus size={16} />
          Agregar nueva meta
        </motion.button>
      )}
    </motion.div>
  );
}
