import React, { useState } from "react";
import { useNavigate } from "react-router";
import { motion } from "motion/react";
import { useGoals } from "../context/GoalsContext";
import {
  Dumbbell, DollarSign, BookOpen, Briefcase, Leaf,
  CheckCircle2, CalendarDays, FileText, Tag, ArrowLeft, Sparkles,
  Plane, Heart, User, GraduationCap
} from "lucide-react";
import { CategorySelector } from "../components/create-goal/CategorySelector";

const CATEGORIES = [
  { id: "Salud", label: "Salud", icon: <Heart size={22} />, color: "#06b6d4", bg: "#ecfeff" },
  { id: "Viajes", label: "Viajes", icon: <Plane size={22} />, color: "#0ea5e9", bg: "#f0f9ff" },
  { id: "Finanzas", label: "Finanzas", icon: <DollarSign size={22} />, color: "#0891b2", bg: "#e0f7fa" },
  { id: "Personal", label: "Personal", icon: <User size={22} />, color: "#0e7490", bg: "#cffafe" },
  { id: "Aprendizaje", label: "Aprendizaje", icon: <GraduationCap size={22} />, color: "#67e8f9", bg: "#f0fdff" },
];

export default function CreateGoalPage() {
  const { addGoal, setSelectedGoalId } = useGoals();
  const navigate = useNavigate();

  const [category, setCategory] = useState<string>("");
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [deadline, setDeadline] = useState("");
  const [success, setSuccess] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [formError, setFormError] = useState("");

  const validate = () => {
    const e: Record<string, string> = {};
    if (!name.trim()) e.name = "El nombre es requerido";
    if (!description.trim()) e.description = "La descripción es requerida";
    if (!deadline) e.deadline = "La fecha límite es requerida";
    if (!category) e.category = "Selecciona una categoría";
    return e;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError("");
    const errs = validate();
    setErrors(errs);
    if (Object.keys(errs).length > 0) return;

    try {
      const cat = CATEGORIES.find((c) => c.id === category);
      await addGoal({
        nombre: name.trim(),
        descripcion: description.trim(),
        deadline,
        category,
        color: cat?.color || "#06b6d4",
      });

      setSuccess(true);
      // Esperar un poco para que el usuario vea el mensaje de éxito
      setTimeout(() => {
        navigate("/dashboard");
      }, 2000);
    } catch (err: any) {
      console.error("Error creating goal:", err);
      const errorCode = err.code || "unknown";
      setFormError(`Error (${errorCode}): No se pudo crear la meta. Revisa las reglas de Firestore en tu consola.`);
    }
  };

  return (
    <div>
      <div className="flex items-center gap-3 mb-6">
        <button
          onClick={() => navigate("/dashboard")}
          className="w-9 h-9 rounded-xl flex items-center justify-center transition-all"
          style={{ background: "rgba(14,165,233,0.1)", color: "#0891b2" }}
        >
          <ArrowLeft size={18} />
        </button>
        <div>
          <h1 style={{ color: "#0e7490" }}>Crear Nueva Meta</h1>
          <p style={{ color: "#0891b2", fontSize: "0.875rem" }}>
            Define tu objetivo y empieza a avanzar
          </p>
        </div>
      </div>

      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="rounded-2xl p-6"
        style={{
          background: "rgba(255,255,255,0.85)",
          backdropFilter: "blur(12px)",
          boxShadow: "0 4px 24px rgba(14,165,233,0.12)",
          border: "1px solid rgba(14,165,233,0.15)",
        }}
      >
        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <div className="flex items-center gap-2 mb-3">
              <Tag size={16} style={{ color: "#0891b2" }} />
              <label style={{ color: "#0e7490", fontSize: "0.95rem" }}>Categoría de la meta</label>
            </div>
            <CategorySelector
              categories={CATEGORIES}
              selectedId={category}
              onSelect={(id) => {
                setCategory(id);
                setErrors((prev) => ({ ...prev, category: "" }));
              }}
            />
            {errors.category && (
              <p className="mt-1.5" style={{ color: "#ef4444", fontSize: "0.8rem" }}>{errors.category}</p>
            )}
          </div>

          <div style={{ height: "1px", background: "rgba(14,165,233,0.12)" }} />

          <div>
            <div className="flex items-center gap-2 mb-2">
              <Sparkles size={15} style={{ color: "#0891b2" }} />
              <label style={{ color: "#0e7490", fontSize: "0.95rem" }}>Nombre de la meta</label>
            </div>
            <input
              type="text"
              value={name}
              onChange={(e) => {
                setName(e.target.value);
                setErrors((prev) => ({ ...prev, name: "" }));
              }}
              placeholder="Ej: Correr 5km, Aprender inglés..."
              className="w-full px-4 py-3 rounded-xl outline-none transition-all"
              style={{
                background: "#f0f9ff",
                border: errors.name ? "2px solid #ef4444" : "2px solid rgba(14,165,233,0.2)",
                color: "#0e7490",
                fontSize: "0.95rem",
              }}
            />
            {errors.name && <p className="mt-1" style={{ color: "#ef4444", fontSize: "0.8rem" }}>{errors.name}</p>}
          </div>

          <div>
            <div className="flex items-center gap-2 mb-2">
              <FileText size={15} style={{ color: "#0891b2" }} />
              <label style={{ color: "#0e7490", fontSize: "0.95rem" }}>Descripción</label>
            </div>
            <textarea
              value={description}
              onChange={(e) => {
                setDescription(e.target.value);
                setErrors((prev) => ({ ...prev, description: "" }));
              }}
              placeholder="Describe tu meta en detalle..."
              rows={3}
              className="w-full px-4 py-3 rounded-xl outline-none transition-all resize-none"
              style={{
                background: "#f0f9ff",
                border: errors.description ? "2px solid #ef4444" : "2px solid rgba(14,165,233,0.2)",
                color: "#0e7490",
                fontSize: "0.95rem",
              }}
            />
            {errors.description && <p className="mt-1" style={{ color: "#ef4444", fontSize: "0.8rem" }}>{errors.description}</p>}
          </div>

          <div>
            <div className="flex items-center gap-2 mb-2">
              <CalendarDays size={15} style={{ color: "#0891b2" }} />
              <label style={{ color: "#0e7490", fontSize: "0.95rem" }}>Fecha límite</label>
            </div>
            <input
              type="date"
              value={deadline}
              onChange={(e) => {
                setDeadline(e.target.value);
                setErrors((prev) => ({ ...prev, deadline: "" }));
              }}
              min={new Date().toISOString().split("T")[0]}
              className="w-full px-4 py-3 rounded-xl outline-none transition-all"
              style={{
                background: "#f0f9ff",
                border: errors.deadline ? "2px solid #ef4444" : "2px solid rgba(14,165,233,0.2)",
                color: "#0e7490",
                fontSize: "0.95rem",
              }}
            />
            {errors.deadline && <p className="mt-1" style={{ color: "#ef4444", fontSize: "0.8rem" }}>{errors.deadline}</p>}
          </div>

          {formError && (
            <p className="text-center p-3 rounded-xl" style={{ background: "rgba(239,68,68,0.1)", color: "#ef4444", fontSize: "0.875rem" }}>
              {formError}
            </p>
          )}

          {success && (
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="text-center p-4 rounded-xl"
              style={{ 
                background: "rgba(34,197,94,0.1)", 
                color: "#16a34a", 
                border: "1px solid rgba(34,197,94,0.2)",
                fontSize: "0.95rem"
              }}
            >
              <div className="flex items-center justify-center gap-2 font-bold mb-1">
                <CheckCircle2 size={18} />
                ¡Meta creada con éxito!
              </div>
              <p className="text-sm opacity-80">Volviendo al dashboard...</p>
            </motion.div>
          )}

          <motion.button
            type="submit"
            disabled={success}
            whileTap={{ scale: 0.97 }}
            className="w-full py-3.5 rounded-xl transition-all flex items-center justify-center gap-2"
            style={{
              background: success
                ? "linear-gradient(135deg, #4ade80, #22c55e)"
                : "linear-gradient(135deg, #0ea5e9, #06b6d4)",
              color: "white",
              fontWeight: 700,
              fontSize: "1rem",
              boxShadow: "0 4px 16px rgba(14,165,233,0.35)",
              opacity: success ? 0.8 : 1
            }}
          >
            {success ? <><CheckCircle2 size={20} /> ¡Meta creada!</> : <><Sparkles size={18} /> Crear Meta</>}
          </motion.button>
        </form>
      </motion.div>
    </div>
  );
}
