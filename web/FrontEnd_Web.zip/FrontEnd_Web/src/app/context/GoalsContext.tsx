import React, { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { 
  signInWithEmailAndPassword, 
  signOut, 
  onAuthStateChanged,
  createUserWithEmailAndPassword,
  updateProfile
} from "firebase/auth";
import { 
  collection, 
  doc, 
  addDoc, 
  updateDoc, 
  deleteDoc, 
  onSnapshot, 
  query, 
  where,
  setDoc,
  serverTimestamp,
  arrayUnion
} from "firebase/firestore";
import { auth, db } from "../../lib/firebase";
import { generateMilestones } from "../../lib/gemini";

export interface Milestone {
  id: string;
  text: string;
  completed: boolean;
}

export interface Goal {
  id: string;
  nombre: string;
  descripcion: string;
  deadline: string;
  category: string;
  color: string;
  milestones: Milestone[];
  createdAt: string;
  userId: string;
}

export interface User {
  email: string;
  name: string;
  uid: string;
}

interface GoalsContextType {
  user: User | null;
  goals: Goal[];
  selectedGoalId: string | null;
  login: (email: string, password: string) => Promise<boolean>;
  register: (email: string, password: string, name: string) => Promise<boolean>;
  logout: () => Promise<void>;
  addGoal: (goal: Omit<Goal, "id" | "createdAt" | "milestones" | "userId">) => Promise<string>;
  deleteGoal: (goalId: string) => Promise<void>;
  addMilestone: (goalId: string, text: string) => Promise<void>;
  toggleMilestone: (goalId: string, milestoneId: string) => Promise<void>;
  deleteMilestone: (goalId: string, milestoneId: string) => Promise<void>;
  setSelectedGoalId: (id: string | null) => void;
  loading: boolean;
}

const GoalsContext = createContext<GoalsContextType | null>(null);

export function GoalsProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [goals, setGoals] = useState<Goal[]>([]);
  const [selectedGoalId, setSelectedGoalId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  // Auth state listener
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (firebaseUser) => {
      if (firebaseUser) {
        const name = firebaseUser.displayName || firebaseUser.email?.split("@")[0] || "User";
        setUser({ 
          email: firebaseUser.email || "", 
          name: name.charAt(0).toUpperCase() + name.slice(1),
          uid: firebaseUser.uid
        });
      } else {
        setUser(null);
        setGoals([]);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  // Goals real-time listener
  useEffect(() => {
    if (!user) return;

    // Según tus reglas, la colección se llama "metas"
    const q = query(collection(db, "metas"), where("userId", "==", user.uid));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const goalsData: Goal[] = [];
      snapshot.forEach((doc) => {
        goalsData.push({ id: doc.id, ...doc.data() } as Goal);
      });
      setGoals(goalsData.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()));
    });

    return () => unsubscribe();
  }, [user]);

  const login = async (email: string, password: string): Promise<boolean> => {
    try {
      await signInWithEmailAndPassword(auth, email, password);
      return true;
    } catch (error) {
      console.error("Login error:", error);
      return false;
    }
  };

  const register = async (email: string, password: string, name: string): Promise<boolean> => {
    try {
      const userCredential = await createUserWithEmailAndPassword(auth, email, password);
      const firebaseUser = userCredential.user;
      
      // Actualizar el nombre en el perfil de Auth
      await updateProfile(firebaseUser, { displayName: name });
      
      // Guardar perfil de usuario en Firestore (usando la colección 'usuarios' de tus reglas)
      await setDoc(doc(db, "usuarios", firebaseUser.uid), {
        name,
        email,
        createdAt: serverTimestamp()
      });
      
      return true;
    } catch (error) {
      console.error("Registration error:", error);
      return false;
    }
  };

  const logout = async () => {
    await signOut(auth);
    setSelectedGoalId(null);
  };

  const addGoal = async (goal: Omit<Goal, "id" | "createdAt" | "milestones" | "userId">): Promise<string> => {
    if (!user) {
      console.error("AddGoal Error: No user authenticated");
      throw new Error("User not authenticated");
    }

    try {
      // Generar hitos personalizados usando Gemini
      const suggestedMilestones = await generateMilestones(
        goal.nombre, 
        goal.descripcion, 
        goal.category,
        goal.deadline
      );
      
      const milestones: Milestone[] = suggestedMilestones.map((text: string, index: number) => ({
        id: `${Date.now()}-${index}`,
        text,
        completed: false
      }));

      const goalData = {
        ...goal,
        userId: user.uid,
        milestones,
        createdAt: new Date().toISOString().split("T")[0],
      };

      // Cambiado a "metas" para coincidir con tus reglas
      const docRef = await addDoc(collection(db, "metas"), goalData);
      return docRef.id;
    } catch (error: any) {
      console.error("Firestore Error in addGoal:", error.code, error.message);
      throw error;
    }
  };

  const deleteGoal = async (goalId: string) => {
    // Cambiado a "metas"
    await deleteDoc(doc(db, "metas", goalId));
    if (selectedGoalId === goalId) setSelectedGoalId(null);
  };

  const addMilestone = async (goalId: string, text: string) => {
    // Cambiado a "metas"
    const goalRef = doc(db, "metas", goalId);
    const newMilestone: Milestone = {
      id: Date.now().toString(),
      text,
      completed: false
    };
    
    await updateDoc(goalRef, {
      milestones: arrayUnion(newMilestone)
    });
  };

  const toggleMilestone = async (goalId: string, milestoneId: string) => {
    const goal = goals.find(g => g.id === goalId);
    if (!goal) return;

    const updatedMilestones = goal.milestones.map(m => 
      m.id === milestoneId ? { ...m, completed: !m.completed } : m
    );

    // Cambiado a "metas"
    await updateDoc(doc(db, "metas", goalId), {
      milestones: updatedMilestones
    });
  };

  const deleteMilestone = async (goalId: string, milestoneId: string) => {
    const goal = goals.find(g => g.id === goalId);
    if (!goal) return;

    const updatedMilestones = goal.milestones.filter(m => m.id !== milestoneId);

    // Cambiado a "metas"
    await updateDoc(doc(db, "metas", goalId), {
      milestones: updatedMilestones
    });
  };

  return (
    <GoalsContext.Provider
      value={{
        user,
        goals,
        selectedGoalId,
        login,
        register,
        logout,
        addGoal,
        deleteGoal,
        addMilestone,
        toggleMilestone,
        deleteMilestone,
        setSelectedGoalId,
        loading
      }}
    >
      {children}
    </GoalsContext.Provider>
  );
}

export function useGoals() {
  const ctx = useContext(GoalsContext);
  if (!ctx) throw new Error("useGoals must be used within GoalsProvider");
  return ctx;
}
