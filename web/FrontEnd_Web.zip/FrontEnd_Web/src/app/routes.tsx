import React from "react";
import { createBrowserRouter, Navigate, Outlet } from "react-router";
import Layout from "./components/Layout";
import LoginPage from "./pages/LoginPage";
import CreateGoalPage from "./pages/CreateGoalPage";
import DashboardPage from "./pages/DashboardPage";
import { useGoals } from "./context/GoalsContext";

// Guard: only logged-in users
function ProtectedLayout() {
  const { user, loading } = useGoals();
  if (loading) return (
    <div className="min-h-screen flex items-center justify-center bg-cyan-50">
      <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-cyan-600"></div>
    </div>
  );
  if (!user) return <Navigate to="/login" replace />;
  return (
    <Layout />
  );
}

// Guard: only guests
function GuestRoute() {
  const { user, loading } = useGoals();
  if (loading) return (
    <div className="min-h-screen flex items-center justify-center bg-cyan-50">
      <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-cyan-600"></div>
    </div>
  );
  if (user) return <Navigate to="/dashboard" replace />;
  return <LoginPage />;
}

export const router = createBrowserRouter([
  {
    path: "/",
    element: <Navigate to="/login" replace />,
  },
  {
    path: "/login",
    Component: GuestRoute,
  },
  {
    path: "/",
    Component: ProtectedLayout,
    children: [
      { path: "dashboard", Component: DashboardPage },
      { path: "create", Component: CreateGoalPage },
      { index: true, element: <Navigate to="/dashboard" replace /> },
    ],
  },
  {
    path: "*",
    element: <Navigate to="/login" replace />,
  },
]);
