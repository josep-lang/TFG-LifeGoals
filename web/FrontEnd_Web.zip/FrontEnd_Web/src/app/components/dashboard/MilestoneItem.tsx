import React from "react";
import { motion } from "motion/react";
import { CheckCircle2, Circle, Trash2 } from "lucide-react";

interface MilestoneItemProps {
  milestone: any;
  onToggle: () => void;
  onDelete: () => void;
  delay?: number;
}

export function MilestoneItem({ milestone, onToggle, onDelete, delay = 0 }: MilestoneItemProps) {
  return (
    <motion.div
      initial={{ opacity: 0, x: -12 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: 12, height: 0 }}
      transition={{ duration: 0.2, delay }}
      className="flex items-center gap-3 p-3 rounded-xl group transition-all"
      style={{
        background: milestone.completed ? "#f0fdf4" : "#f8fafc",
        border: milestone.completed ? "1px solid #bbf7d0" : "1px solid rgba(14,165,233,0.1)",
      }}
    >
      <button onClick={onToggle} className="flex-shrink-0 transition-all">
        {milestone.completed ? (
          <CheckCircle2 size={22} style={{ color: "#22c55e" }} />
        ) : (
          <Circle size={22} style={{ color: "#94a3b8" }} />
        )}
      </button>
      <span
        className="flex-1"
        style={{
          color: milestone.completed ? "#4ade80" : "#0e7490",
          fontSize: "0.875rem",
          textDecoration: milestone.completed ? "line-through" : "none",
          opacity: milestone.completed ? 0.75 : 1,
        }}
      >
        {milestone.text}
      </span>
    </motion.div>
  );
}
