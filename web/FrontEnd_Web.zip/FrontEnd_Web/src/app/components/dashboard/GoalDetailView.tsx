import React from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  ChevronRight, Target, Trash2, CalendarDays, Flag, X, Plus, Trophy
} from "lucide-react";
import { MilestoneItem } from "./MilestoneItem";

interface GoalDetailViewProps {
  goal: any;
  onBack: () => void;
  onDeleteRequest: () => void;
  onToggleMilestone: (milestoneId: string) => void;
  onDeleteMilestone: (milestoneId: string) => void;
  onAddMilestone: (text: string) => void;
  categoryIcon: React.ReactNode;
  categoryColor: any;
  formatDeadline: (date: string) => string;
  daysLeft: (date: string) => number;
  progress: number;
}

export function GoalDetailView({
  goal,
  onBack,
  onDeleteRequest,
  onToggleMilestone,
  onDeleteMilestone,
  onAddMilestone,
  categoryIcon,
  categoryColor,
  formatDeadline,
  daysLeft,
  progress,
}: GoalDetailViewProps) {
  const [newMilestone, setNewMilestone] = React.useState("");
  const [addingMilestone, setAddingMilestone] = React.useState(false);

  const days = daysLeft(goal.deadline);
  const completedCount = goal.milestones.filter((m: any) => m.completed).length;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMilestone.trim()) return;
    onAddMilestone(newMilestone.trim());
    setNewMilestone("");
    setAddingMilestone(false);
  };

  return (
    <motion.div
      key={goal.id}
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35 }}
    >
      <button
        onClick={onBack}
        className="flex items-center gap-2 mb-5 transition-all"
        style={{ color: "#0891b2" }}
      >
        <ChevronRight size={16} style={{ transform: "rotate(180deg)" }} />
        <span style={{ fontSize: "0.875rem" }}>Todas las metas</span>
      </button>

      <div
        className="rounded-2xl p-5 mb-4 relative overflow-hidden"
        style={{
          background: `linear-gradient(135deg, ${categoryColor.main} 0%, #0ea5e9 100%)`,
          boxShadow: `0 8px 32px ${categoryColor.main}50`,
        }}
      >
        <div className="absolute top-[-30px] right-[-30px] w-40 h-40 rounded-full opacity-15"
          style={{ background: "white" }} />
        <div className="absolute bottom-[-20px] left-[-20px] w-28 h-28 rounded-full opacity-10"
          style={{ background: "white" }} />

        <div className="relative z-10">
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 rounded-xl flex items-center justify-center"
                style={{ background: "rgba(255,255,255,0.25)" }}>
                <span className="text-white">{categoryIcon}</span>
              </div>
              <span className="px-2.5 py-1 rounded-full text-white"
                style={{ background: "rgba(255,255,255,0.2)", fontSize: "0.75rem", fontWeight: 600 }}>
                {goal.category.charAt(0).toUpperCase() + goal.category.slice(1)}
              </span>
            </div>
            <button
              onClick={onDeleteRequest}
              className="w-8 h-8 rounded-lg flex items-center justify-center transition-all hover:bg-white/20"
              style={{ color: "rgba(255,255,255,0.7)" }}
            >
              <Trash2 size={15} />
            </button>
          </div>

          <h2 className="text-white mb-1" style={{ fontWeight: 700, fontSize: "1.3rem" }}>
            {goal.nombre}
          </h2>
          <p style={{ color: "rgba(255,255,255,0.8)", fontSize: "0.875rem", lineHeight: 1.5 }}>
            {goal.descripcion}
          </p>

          <div className="flex items-center gap-1.5 mt-3" style={{ color: "rgba(255,255,255,0.7)", fontSize: "0.8rem" }}>
            <CalendarDays size={13} />
            <span>Límite: {formatDeadline(goal.deadline)}</span>
            {days >= 0 ? (
              <span className="ml-1 px-2 py-0.5 rounded-full"
                style={{ background: "rgba(255,255,255,0.18)", fontSize: "0.72rem" }}>
                {days === 0 ? "¡Hoy!" : `${days}d restantes`}
              </span>
            ) : (
              <span className="ml-1 px-2 py-0.5 rounded-full"
                style={{ background: "rgba(239,68,68,0.35)", fontSize: "0.72rem" }}>
                Vencida
              </span>
            )}
          </div>

          <div className="mt-4">
            <div className="flex justify-between mb-1.5">
              <span style={{ color: "rgba(255,255,255,0.75)", fontSize: "0.78rem" }}>
                {completedCount}/{goal.milestones.length} hitos completados
              </span>
              <span style={{ color: "white", fontSize: "0.78rem", fontWeight: 700 }}>{progress}%</span>
            </div>
            <div className="w-full h-2.5 rounded-full" style={{ background: "rgba(255,255,255,0.2)" }}>
              <motion.div
                className="h-2.5 rounded-full"
                style={{ background: progress === 100 ? "#4ade80" : "white" }}
                initial={{ width: 0 }}
                animate={{ width: `${progress}%` }}
                transition={{ duration: 0.6, ease: "easeOut" }}
              />
            </div>
          </div>
        </div>
      </div>

      <div
        className="rounded-2xl p-5"
        style={{
          background: "rgba(255,255,255,0.88)",
          backdropFilter: "blur(12px)",
          boxShadow: "0 4px 24px rgba(14,165,233,0.10)",
          border: "1px solid rgba(14,165,233,0.12)",
        }}
      >
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Flag size={16} style={{ color: categoryColor.main }} />
            <span style={{ color: "#0e7490", fontWeight: 700, fontSize: "1rem" }}>Hitos</span>
          </div>
        </div>

        {goal.milestones.length === 0 ? (
          <div className="text-center py-10">
            <div className="w-14 h-14 rounded-2xl flex items-center justify-center mx-auto mb-3"
              style={{ background: "#f0f9ff" }}>
              <Flag size={24} style={{ color: "#7dd3fc" }} />
            </div>
            <p style={{ color: "#94a3b8", fontSize: "0.875rem" }}>
              Aún no tienes hitos. ¡Añade el primero!
            </p>
          </div>
        ) : (
          <div className="space-y-2.5">
            <AnimatePresence>
              {goal.milestones.map((milestone: any, idx: number) => (
                <MilestoneItem
                  key={milestone.id}
                  milestone={milestone}
                  onToggle={() => onToggleMilestone(milestone.id)}
                  onDelete={() => onDeleteMilestone(milestone.id)}
                  delay={idx * 0.04}
                />
              ))}
            </AnimatePresence>
          </div>
        )}

        {progress === 100 && goal.milestones.length > 0 && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="mt-4 p-4 rounded-xl text-center"
            style={{ background: "linear-gradient(135deg, #f0fdf4, #dcfce7)", border: "1px solid #bbf7d0" }}
          >
            <Trophy size={28} className="mx-auto mb-2" style={{ color: "#22c55e" }} />
            <p style={{ color: "#16a34a", fontWeight: 700 }}>¡Meta completada! 🎉</p>
            <p style={{ color: "#4ade80", fontSize: "0.8rem" }}>Has alcanzado todos tus hitos</p>
          </motion.div>
        )}
      </div>
    </motion.div>
  );
}
