import React from "react";
import { motion } from "motion/react";

interface StatCardProps {
  label: string;
  value: string | number;
  icon: React.ReactNode;
  color: string;
}

export function StatCard({ label, value, icon, color }: StatCardProps) {
  return (
    <motion.div
      whileTap={{ scale: 0.97 }}
      className="rounded-2xl p-4 flex flex-col items-center text-center"
      style={{
        background: "rgba(255,255,255,0.85)",
        backdropFilter: "blur(12px)",
        boxShadow: "0 2px 12px rgba(14,165,233,0.10)",
        border: "1px solid rgba(14,165,233,0.12)",
      }}
    >
      <div
        className="w-9 h-9 rounded-xl flex items-center justify-center mb-2"
        style={{ background: `${color}18`, color: color }}
      >
        {icon}
      </div>
      <span style={{ color: "#0e7490", fontWeight: 700, fontSize: "1.1rem" }}>{value}</span>
      <span style={{ color: "#94a3b8", fontSize: "0.68rem", lineHeight: 1.3 }}>{label}</span>
    </motion.div>
  );
}
