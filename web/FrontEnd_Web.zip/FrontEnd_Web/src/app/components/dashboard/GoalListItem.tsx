import React from "react";
import { motion } from "motion/react";
import { CalendarDays, Trophy, ChevronRight } from "lucide-react";

interface GoalListItemProps {
  goal: any;
  pct: number;
  col: any;
  days: number;
  formatDeadline: (date: string) => string;
  onClick: () => void;
  categoryIcon: React.ReactNode;
  delay?: number;
}

export function GoalListItem({
  goal,
  pct,
  col,
  days,
  formatDeadline,
  onClick,
  categoryIcon,
  delay = 0,
}: GoalListItemProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, delay }}
      whileTap={{ scale: 0.99 }}
      onClick={onClick}
      className="rounded-2xl p-4 cursor-pointer transition-all"
      style={{
        background: "rgba(255,255,255,0.88)",
        backdropFilter: "blur(12px)",
        boxShadow: "0 2px 16px rgba(14,165,233,0.08)",
        border: "1px solid rgba(14,165,233,0.12)",
      }}
      onMouseEnter={(e) => {
        (e.currentTarget as HTMLDivElement).style.boxShadow = `0 6px 24px ${col.main}25`;
        (e.currentTarget as HTMLDivElement).style.border = `1px solid ${col.main}40`;
      }}
      onMouseLeave={(e) => {
        (e.currentTarget as HTMLDivElement).style.boxShadow = "0 2px 16px rgba(14,165,233,0.08)";
        (e.currentTarget as HTMLDivElement).style.border = "1px solid rgba(14,165,233,0.12)";
      }}
    >
      <div className="flex items-start gap-3">
        <div
          className="w-11 h-11 rounded-xl flex items-center justify-center flex-shrink-0"
          style={{ background: `linear-gradient(135deg, ${col.main}, #0ea5e9)`, color: "white" }}
        >
          {categoryIcon}
        </div>

        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between gap-2">
            <div className="min-w-0">
              <h3 className="truncate" style={{ color: "#0e7490", fontWeight: 700, fontSize: "1rem" }}>
                {goal.nombre}
              </h3>
              <p className="truncate mt-0.5" style={{ color: "#64748b", fontSize: "0.8rem" }}>
                {goal.descripcion}
              </p>
            </div>
            <div className="flex items-center gap-1 flex-shrink-0">
              {pct === 100 && (
                <div className="w-6 h-6 rounded-full flex items-center justify-center"
                  style={{ background: "#f0fdf4" }}>
                  <Trophy size={13} style={{ color: "#22c55e" }} />
                </div>
              )}
              <ChevronRight size={16} style={{ color: "#cbd5e1" }} />
            </div>
          </div>

          <div className="mt-3">
            <div className="flex justify-between mb-1">
              <span style={{ color: "#94a3b8", fontSize: "0.72rem" }}>
                {goal.milestones.filter((m: any) => m.completed).length}/{goal.milestones.length} hitos
              </span>
              <span style={{ color: col.main, fontSize: "0.72rem", fontWeight: 700 }}>{pct}%</span>
            </div>
            <div className="w-full h-2 rounded-full" style={{ background: "#f1f5f9" }}>
              <div
                className="h-2 rounded-full transition-all"
                style={{
                  width: `${pct}%`,
                  background: pct === 100
                    ? "linear-gradient(90deg, #4ade80, #22c55e)"
                    : `linear-gradient(90deg, ${col.main}, #0ea5e9)`,
                }}
              />
            </div>
          </div>

          <div className="flex items-center gap-3 mt-2">
            <div className="flex items-center gap-1" style={{ color: "#94a3b8", fontSize: "0.72rem" }}>
              <CalendarDays size={11} />
              <span>{formatDeadline(goal.deadline)}</span>
            </div>
            {days < 0 ? (
              <span className="px-2 py-0.5 rounded-full"
                style={{ background: "#fef2f2", color: "#ef4444", fontSize: "0.68rem", fontWeight: 600 }}>
                Vencida
              </span>
            ) : days <= 7 ? (
              <span className="px-2 py-0.5 rounded-full"
                style={{ background: "#fff7ed", color: "#f97316", fontSize: "0.68rem", fontWeight: 600 }}>
                {days === 0 ? "¡Hoy!" : `${days}d`}
              </span>
            ) : (
              <span className="px-2 py-0.5 rounded-full"
                style={{ background: col.light, color: col.text, fontSize: "0.68rem", fontWeight: 600 }}>
                {days}d restantes
              </span>
            )}
          </div>
        </div>
      </div>
    </motion.div>
  );
}
