import React from "react";
import { motion } from "motion/react";
import { Trash2 } from "lucide-react";

interface ConfirmDeleteModalProps {
  onConfirm: () => void;
  onCancel: () => void;
}

export function ConfirmDeleteModal({ onConfirm, onCancel }: ConfirmDeleteModalProps) {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      style={{ background: "rgba(0,0,0,0.45)", backdropFilter: "blur(4px)" }}
    >
      <motion.div
        initial={{ scale: 0.9, y: 20 }}
        animate={{ scale: 1, y: 0 }}
        exit={{ scale: 0.9, y: 20 }}
        className="w-full max-w-sm rounded-2xl p-6"
        style={{ background: "white", boxShadow: "0 20px 60px rgba(0,0,0,0.2)" }}
      >
        <div className="text-center mb-5">
          <div className="w-14 h-14 rounded-2xl flex items-center justify-center mx-auto mb-3"
            style={{ background: "#fef2f2" }}>
            <Trash2 size={24} style={{ color: "#ef4444" }} />
          </div>
          <h3 style={{ color: "#0e7490", fontWeight: 700 }}>¿Eliminar meta?</h3>
          <p className="mt-1" style={{ color: "#64748b", fontSize: "0.875rem" }}>
            Esta acción no se puede deshacer. Se eliminarán todos los hitos asociados.
          </p>
        </div>
        <div className="flex gap-3">
          <button
            onClick={onCancel}
            className="flex-1 py-2.5 rounded-xl transition-all"
            style={{ background: "#f1f5f9", color: "#64748b", fontWeight: 600 }}
          >
            Cancelar
          </button>
          <button
            onClick={onConfirm}
            className="flex-1 py-2.5 rounded-xl transition-all"
            style={{ background: "linear-gradient(135deg, #ef4444, #dc2626)", color: "white", fontWeight: 600 }}
          >
            Eliminar
          </button>
        </div>
      </motion.div>
    </motion.div>
  );
}
