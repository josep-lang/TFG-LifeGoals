import React, { useState } from "react";
import { Outlet, useNavigate } from "react-router";
import { motion } from "motion/react";
import { Menu, Plus, Target, Bell } from "lucide-react";
import Sidebar from "./Sidebar";
import { useGoals } from "../context/GoalsContext";

export default function Layout() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const { user } = useGoals();
  const navigate = useNavigate();

  return (
    <div className="min-h-screen" style={{ background: "linear-gradient(135deg, #f0f9ff 0%, #e0f7fa 50%, #cffafe 100%)" }}>
      <Sidebar open={sidebarOpen} onClose={() => setSidebarOpen(false)} />

      {/* Decorative background blobs */}
      <div className="fixed top-0 right-0 w-96 h-96 rounded-full pointer-events-none"
        style={{ background: "radial-gradient(circle, rgba(14,165,233,0.06), transparent)", transform: "translate(30%, -30%)" }} />
      <div className="fixed bottom-0 left-0 w-80 h-80 rounded-full pointer-events-none"
        style={{ background: "radial-gradient(circle, rgba(6,182,212,0.07), transparent)", transform: "translate(-30%, 30%)" }} />

      {/* Top navbar */}
      <header className="sticky top-0 z-30 px-4 py-3 flex items-center justify-between"
        style={{
          background: "rgba(255,255,255,0.8)",
          backdropFilter: "blur(16px)",
          borderBottom: "1px solid rgba(14,165,233,0.15)",
          boxShadow: "0 2px 12px rgba(14,165,233,0.08)",
        }}>
        <div className="flex items-center gap-3">
          <motion.button
            whileTap={{ scale: 0.92 }}
            onClick={() => setSidebarOpen(true)}
            className="w-10 h-10 rounded-xl flex items-center justify-center transition-all"
            style={{ background: "linear-gradient(135deg, #0ea5e9, #06b6d4)", color: "white" }}
          >
            <Menu size={20} />
          </motion.button>
          <button 
            onClick={() => { setSelectedGoalId(null); navigate("/dashboard"); }}
            className="flex items-center gap-2 transition-opacity hover:opacity-80"
          >
            <Target size={20} style={{ color: "#0891b2" }} />
            <span style={{ color: "#0e7490", fontWeight: 700, fontSize: "1.1rem" }}>
              LifeGoals
            </span>
          </button>
        </div>

        <div className="flex items-center gap-2">
          <motion.button
            whileTap={{ scale: 0.92 }}
            onClick={() => navigate("/create")}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl transition-all"
            style={{ background: "linear-gradient(135deg, #0ea5e9, #06b6d4)", color: "white" }}
          >
            <Plus size={16} />
            <span className="hidden sm:inline" style={{ fontSize: "0.875rem" }}>
              Nueva Meta
            </span>
          </motion.button>
          {user && (
            <div className="w-9 h-9 rounded-xl flex items-center justify-center"
              style={{ background: "linear-gradient(135deg, #0891b2, #06b6d4)", color: "white", fontWeight: 700, fontSize: "0.9rem" }}>
              {user.name.charAt(0).toUpperCase()}
            </div>
          )}
        </div>
      </header>

      {/* Page content */}
      <main className="max-w-4xl mx-auto px-4 py-6">
        <Outlet />
      </main>
    </div>
  );
}