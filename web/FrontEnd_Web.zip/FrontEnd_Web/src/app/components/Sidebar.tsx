import React from "react";
import { useNavigate, useLocation } from "react-router";
import { motion, AnimatePresence } from "motion/react";
import { useGoals } from "../context/GoalsContext";
import {
  Target, Plus, Home, LogOut, X, CheckCircle2, Circle,
  Dumbbell, DollarSign, BookOpen, Briefcase, Leaf, Star
} from "lucide-react";

const categoryIcons: Record<string, React.ReactNode> = {
  fitness: <Dumbbell size={16} />,
  finanzas: <DollarSign size={16} />,
  educacion: <BookOpen size={16} />,
  carrera: <Briefcase size={16} />,
  personal: <Leaf size={16} />,
};

const categoryColors: Record<string, string> = {
  fitness: "#06b6d4",
  finanzas: "#0ea5e9",
  educacion: "#38bdf8",
  carrera: "#7dd3fc",
  personal: "#67e8f9",
};

interface SidebarProps {
  open: boolean;
  onClose: () => void;
}

export default function Sidebar({ open, onClose }: SidebarProps) {
  const { goals, selectedGoalId, setSelectedGoalId, user, logout } = useGoals();
  const navigate = useNavigate();
  const location = useLocation();

  const handleGoalClick = (id: string) => {
    setSelectedGoalId(id);
    navigate("/dashboard");
    onClose();
  };

  const handleLogout = async () => {
    await logout();
    navigate("/login");
    onClose();
  };

  const progress = (g: typeof goals[0]) => {
    if (g.milestones.length === 0) return 0;
    return Math.round((g.milestones.filter((m) => m.completed).length / g.milestones.length) * 100);
  };

  return (
    <>
      {/* Overlay */}
      <AnimatePresence>
        {open && (
          <motion.div
            key="overlay"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="fixed inset-0 z-40 md:hidden"
            style={{ background: "rgba(0,0,0,0.4)", backdropFilter: "blur(2px)" }}
            onClick={onClose}
          />
        )}
      </AnimatePresence>

      {/* Sidebar panel */}
      <AnimatePresence>
        {open && (
          <motion.aside
            key="sidebar"
            initial={{ x: "-100%" }}
            animate={{ x: 0 }}
            exit={{ x: "-100%" }}
            transition={{ type: "spring", stiffness: 320, damping: 32 }}
            className="fixed top-0 left-0 h-full z-50 w-72 flex flex-col"
            style={{
              background: "linear-gradient(180deg, #0e7490 0%, #0891b2 40%, #0ea5e9 100%)",
              boxShadow: "4px 0 24px rgba(0,0,0,0.2)",
            }}
          >
            {/* Header */}
            <div className="flex items-center justify-between px-5 pt-6 pb-5">
              <button 
                onClick={() => { setSelectedGoalId(null); navigate("/dashboard"); onClose(); }}
                className="flex items-center gap-3 text-left transition-opacity hover:opacity-80"
              >
                <div className="w-10 h-10 rounded-xl flex items-center justify-center"
                  style={{ background: "rgba(255,255,255,0.2)" }}>
                  <Target className="text-white" size={20} />
                </div>
                <div>
                  <p className="text-white" style={{ fontWeight: 700, fontSize: "1rem", lineHeight: 1.2 }}>
                    LifeGoals
                  </p>
                  {user && (
                    <p style={{ color: "rgba(255,255,255,0.65)", fontSize: "0.75rem" }}>
                      {user.name}
                    </p>
                  )}
                </div>
              </button>
              <button
                onClick={onClose}
                className="w-8 h-8 rounded-lg flex items-center justify-center transition-all hover:bg-white/20"
                style={{ color: "rgba(255,255,255,0.7)" }}
              >
                <X size={18} />
              </button>
            </div>

            <div className="px-3 mb-2">
              <div style={{ height: "1px", background: "rgba(255,255,255,0.15)" }} />
            </div>

            {/* Nav links */}
            <div className="px-3 space-y-1">
              <button
                onClick={() => { setSelectedGoalId(null); navigate("/dashboard"); onClose(); }}
                className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl transition-all text-left"
                style={{
                  background: (location.pathname === "/dashboard" && !selectedGoalId) ? "rgba(255,255,255,0.2)" : "transparent",
                  color: "white",
                }}
              >
                <Home size={16} />
                <span style={{ fontSize: "0.875rem" }}>Inicio</span>
              </button>
              <button
                onClick={() => { navigate("/create"); onClose(); }}
                className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl transition-all text-left"
                style={{
                  background: location.pathname === "/create" ? "rgba(255,255,255,0.2)" : "transparent",
                  color: "white",
                }}
              >
                <Plus size={16} />
                <span style={{ fontSize: "0.875rem" }}>Nueva Meta</span>
              </button>
            </div>

            <div className="px-3 my-3">
              <div style={{ height: "1px", background: "rgba(255,255,255,0.15)" }} />
            </div>

            {/* Goals list */}
            <div className="flex items-center px-5 mb-2">
              <Star size={13} style={{ color: "rgba(255,255,255,0.5)" }} />
              <p className="ml-1.5" style={{ color: "rgba(255,255,255,0.5)", fontSize: "0.7rem", letterSpacing: "0.08em", textTransform: "uppercase" }}>
                Mis Metas ({goals.length})
              </p>
            </div>

            <div className="flex-1 overflow-y-auto px-3 space-y-1.5 pb-4">
              {goals.length === 0 && (
                <div className="text-center py-8 px-4">
                  <p style={{ color: "rgba(255,255,255,0.4)", fontSize: "0.85rem" }}>
                    Aún no tienes metas. ¡Crea la primera!
                  </p>
                </div>
              )}
              {goals.map((goal) => {
                const pct = progress(goal);
                const isSelected = goal.id === selectedGoalId;
                return (
                  <motion.button
                    key={goal.id}
                    whileTap={{ scale: 0.98 }}
                    onClick={() => handleGoalClick(goal.id)}
                    className="w-full text-left px-3 py-2.5 rounded-xl transition-all"
                    style={{
                      background: isSelected ? "rgba(255,255,255,0.22)" : "rgba(255,255,255,0.08)",
                      border: isSelected ? "1px solid rgba(255,255,255,0.35)" : "1px solid transparent",
                    }}
                  >
                    <div className="flex items-start gap-2">
                      <div className="w-6 h-6 rounded-lg flex items-center justify-center flex-shrink-0 mt-0.5"
                        style={{ background: "rgba(255,255,255,0.2)", color: "white" }}>
                        {categoryIcons[goal.category] || <Target size={14} />}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-white truncate" style={{ fontSize: "0.85rem", fontWeight: 600 }}>
                          {goal.nombre}
                        </p>
                        <div className="flex items-center gap-1.5 mt-1">
                          <div className="flex-1 h-1 rounded-full" style={{ background: "rgba(255,255,255,0.2)" }}>
                            <div
                              className="h-1 rounded-full transition-all"
                              style={{ width: `${pct}%`, background: pct === 100 ? "#4ade80" : "rgba(255,255,255,0.8)" }}
                            />
                          </div>
                          <span style={{ color: "rgba(255,255,255,0.6)", fontSize: "0.7rem" }}>{pct}%</span>
                        </div>
                      </div>
                    </div>
                  </motion.button>
                );
              })}
            </div>

            {/* Footer */}
            <div className="px-3 pb-6 pt-2">
              <div style={{ height: "1px", background: "rgba(255,255,255,0.15)", marginBottom: "12px" }} />
              <button
                onClick={handleLogout}
                className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl transition-all"
                style={{ color: "rgba(255,255,255,0.7)" }}
                onMouseEnter={(e) => (e.currentTarget.style.background = "rgba(255,255,255,0.1)")}
                onMouseLeave={(e) => (e.currentTarget.style.background = "transparent")}
              >
                <LogOut size={16} />
                <span style={{ fontSize: "0.875rem" }}>Cerrar sesión</span>
              </button>
            </div>
          </motion.aside>
        )}
      </AnimatePresence>
    </>
  );
}