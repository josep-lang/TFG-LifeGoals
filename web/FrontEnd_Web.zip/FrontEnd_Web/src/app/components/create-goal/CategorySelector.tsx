import React from "react";
import { motion } from "motion/react";

interface Category {
  id: string;
  label: string;
  icon: React.ReactNode;
  color: string;
  bg: string;
}

interface CategorySelectorProps {
  categories: Category[];
  selectedId: string;
  onSelect: (id: string) => void;
}

export function CategorySelector({ categories, selectedId, onSelect }: CategorySelectorProps) {
  return (
    <div className="grid grid-cols-5 gap-2 sm:gap-3">
      {categories.map((cat) => {
        const selected = selectedId === cat.id;
        return (
          <motion.button
            key={cat.id}
            type="button"
            whileTap={{ scale: 0.94 }}
            onClick={() => onSelect(cat.id)}
            className="flex flex-col items-center gap-1.5 py-3 px-1 rounded-xl transition-all"
            style={{
              background: selected ? cat.color : cat.bg,
              border: selected ? `2px solid ${cat.color}` : "2px solid transparent",
              color: selected ? "white" : cat.color,
              boxShadow: selected ? `0 4px 12px ${cat.color}40` : "none",
            }}
          >
            <span>{cat.icon}</span>
            <span style={{ fontSize: "0.7rem", fontWeight: 600 }}>{cat.label}</span>
          </motion.button>
        );
      })}
    </div>
  );
}
