
  # Aplicación Android con 4 pantallas

Este proyecto es una aplicación de gestión de metas personales.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  