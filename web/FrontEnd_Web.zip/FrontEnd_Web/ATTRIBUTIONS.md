# Atribuciones

Este proyecto incluye componentes de [shadcn/ui](https://ui.shadcn.com/) bajo la [licencia MIT](https://github.com/shadcn-ui/ui/blob/main/LICENSE.md).

Las fotos utilizadas son de [Unsplash](https://unsplash.com) bajo su [licencia](https://unsplash.com/license).
