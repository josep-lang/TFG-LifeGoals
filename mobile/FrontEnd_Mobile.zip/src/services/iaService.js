import { GoogleGenerativeAI } from "@google/generative-ai";


const GOOGLE_AI_KEY = "AIzaSyA1YRtE-AXXZQrEAOAMxv4X50KL4U5zT3c";
const API_URL = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${GOOGLE_AI_KEY}`;

export async function generarHitosIA(titulo, descripcion, fechaLimite) {
  console.log('[IA] Generando hitos para:', titulo);

  try {
    const prompt = `Eres un coach de productividad experto.
Divide este objetivo en exactamente 5 hitos concretos y accionables.
OBJETIVO: "${titulo}"
DESCRIPCIÓN: "${descripcion || 'Sin descripción'}"
FECHA LÍMITE: ${fechaLimite || 'Sin fecha'}

IMPORTANTE: Responde SOLO con un array JSON. Sin texto antes ni después. Sin markdown.
Formato exacto: ["Hito uno", "Hito dos", "Hito tres", "Hito cuatro", "Hito cinco"]`;

    const response = await fetch(API_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        contents: [{ parts: [{ text: prompt }] }],
        generationConfig: {
          temperature: 0.7,
          maxOutputTokens: 2048,
        }
      })
    });

    const data = await response.json();

    // Mostrar respuesta completa para debug
    console.log('[IA] Status HTTP:', response.status);
    console.log('[IA] Respuesta completa:', JSON.stringify(data, null, 2));

    if (!response.ok || data.error) {
      throw new Error(data.error?.message || `HTTP ${response.status}`);
    }

    const rawText = data.candidates?.[0]?.content?.parts?.[0]?.text?.trim();
    console.log('[IA] Texto recibido:', rawText);

    if (!rawText) throw new Error('Respuesta vacía');

    // Extraer el array JSON de la respuesta
    const jsonMatch = rawText.match(/\[[\s\S]*?\]/);
    if (!jsonMatch) throw new Error('No se encontró JSON en: ' + rawText);

    // Limpiar comillas tipográficas que rompen JSON.parse
    const jsonLimpio = jsonMatch[0]
      .replace(/[\u201C\u201D]/g, '"')  // " " → "
      .replace(/[\u2018\u2019]/g, "'"); // ' ' → '

    const hitos = JSON.parse(jsonLimpio);

    if (!Array.isArray(hitos) || hitos.length === 0) {
      throw new Error('Array inválido o vacío');
    }

    console.log('[IA] Hitos generados correctamente:', hitos);
    return hitos;

  } catch (error) {
    console.error('[IA] Error:', error.message);
    return hitosGenericos(titulo);
  }
}

function hitosGenericos(titulo) {
  return [
    `Definir el plan de acción para: ${titulo}`,
    'Identificar y conseguir los recursos necesarios',
    'Ejecutar la primera fase del plan',
    'Revisar el progreso y ajustar la estrategia',
    'Completar y consolidar el objetivo final',
  ];
}