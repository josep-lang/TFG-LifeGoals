import React, { createContext, useContext, useState, useEffect } from "react";
import {
  signInWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
  createUserWithEmailAndPassword,
  updateProfile,
  updatePassword,
  EmailAuthProvider,
  reauthenticateWithCredential
} from "firebase/auth";
import {
  collection,
  doc,
  addDoc,
  updateDoc,
  deleteDoc,
  onSnapshot,
  query,
  where,
  setDoc,
  serverTimestamp,
  arrayUnion
} from "firebase/firestore";
import { auth, db } from "../../lib/firebase";

const GoalsContext = createContext(null);

export function GoalsProvider({ children }) {
  const [user, setUser]                   = useState(null);
  const [goals, setGoals]                 = useState([]);
  const [selectedGoalId, setSelectedGoalId] = useState(null);
  const [loading, setLoading]             = useState(true);

  // Auth state listener
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (firebaseUser) => {
      if (firebaseUser) {
        const name = firebaseUser.displayName || firebaseUser.email?.split("@")[0] || "User";
        setUser({
          email: firebaseUser.email || "",
          name: name.charAt(0).toUpperCase() + name.slice(1),
          uid: firebaseUser.uid
        });
      } else {
        setUser(null);
        setGoals([]);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  // Goals real-time listener
  useEffect(() => {
    if (!user) return;

    const q = query(collection(db, "metas"), where("userId", "==", user.uid));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const goalsData = [];
      snapshot.forEach((doc) => {
        const data = doc.data();
        goalsData.push({ 
          id: doc.id, 
          ...data,
          milestones: data.milestones || []
        });
      });
      setGoals(
        goalsData.sort(
          (a, b) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime()
        )
      );
    });

    return () => unsubscribe();
  }, [user]);

  const login = async (email, password) => {
    try {
      await signInWithEmailAndPassword(auth, email, password);
      return true;
    } catch (error) {
      console.error("Login error:", error);
      return false;
    }
  };

  const register = async (email, password, name) => {
    try {
      const userCredential = await createUserWithEmailAndPassword(auth, email, password);
      const firebaseUser = userCredential.user;

      await updateProfile(firebaseUser, { displayName: name });

      await setDoc(doc(db, "usuarios", firebaseUser.uid), {
        name,
        email,
        createdAt: serverTimestamp()
      });

      return true;
    } catch (error) {
      console.error("Registration error:", error);
      return false;
    }
  };

  const logout = async () => {
    await signOut(auth);
    setSelectedGoalId(null);
  };

  const updateUserName = async (newName) => {
    if (!auth.currentUser) return false;
    try {
      await updateProfile(auth.currentUser, { displayName: newName });
      await updateDoc(doc(db, "usuarios", auth.currentUser.uid), {
        name: newName
      });
      setUser(prev => ({ ...prev, name: newName }));
      return true;
    } catch (error) {
      console.error("Update name error:", error);
      return false;
    }
  };

  const reauthenticate = async (currentPassword) => {
    if (!auth.currentUser || !auth.currentUser.email) return false;
    try {
      const credential = EmailAuthProvider.credential(auth.currentUser.email, currentPassword);
      await reauthenticateWithCredential(auth.currentUser, credential);
      return true;
    } catch (error) {
      console.error("Reauthentication error:", error);
      return false;
    }
  };

  const updateUserPassword = async (newPassword) => {
    if (!auth.currentUser) return false;
    try {
      await updatePassword(auth.currentUser, newPassword);
      return true;
    } catch (error) {
      console.error("Update password error:", error);
      return false;
    }
  };

  const addGoal = async (goal, initialMilestones = []) => {
    if (!user) {
      console.error("AddGoal Error: No user authenticated");
      throw new Error("User not authenticated");
    }

    try {
      const formattedMilestones = initialMilestones.map((text, index) => ({
        id: (Date.now() + index).toString(),
        text,
        completed: false
      }));

      const goalData = {
        ...goal,
        userId: user.uid,
        milestones: formattedMilestones,
        createdAt: new Date().toISOString().split("T")[0],
      };

      const docRef = await addDoc(collection(db, "metas"), goalData);
      return docRef.id;
    } catch (error) {
      console.error("Firestore Error in addGoal:", error.code, error.message);
      throw error;
    }
  };

  const deleteGoal = async (goalId) => {
    await deleteDoc(doc(db, "metas", goalId));
    if (selectedGoalId === goalId) setSelectedGoalId(null);
  };

  const addMilestone = async (goalId, text) => {
    const goalRef = doc(db, "metas", goalId);
    const newMilestone = {
      id: Date.now().toString(),
      text,
      completed: false
    };

    await updateDoc(goalRef, {
      milestones: arrayUnion(newMilestone)
    });
  };

  const toggleMilestone = async (goalId, milestoneId) => {
    const goal = goals.find(g => g.id === goalId);
    if (!goal) return;

    const updatedMilestones = goal.milestones.map(m =>
      m.id === milestoneId ? { ...m, completed: !m.completed } : m
    );

    await updateDoc(doc(db, "metas", goalId), {
      milestones: updatedMilestones
    });
  };

  const deleteMilestone = async (goalId, milestoneId) => {
    const goal = goals.find(g => g.id === goalId);
    if (!goal) return;

    const updatedMilestones = goal.milestones.filter(m => m.id !== milestoneId);

    await updateDoc(doc(db, "metas", goalId), {
      milestones: updatedMilestones
    });
  };

  return (
    <GoalsContext.Provider
      value={{
        user,
        goals,
        selectedGoalId,
        login,
        register,
        logout,
        updateUserName,
        reauthenticate,
        updateUserPassword,
        addGoal,
        deleteGoal,
        addMilestone,
        toggleMilestone,
        deleteMilestone,
        setSelectedGoalId,
        loading
      }}
    >
      {children}
    </GoalsContext.Provider>
  );
}

export function useGoals() {
  const ctx = useContext(GoalsContext);
  if (!ctx) throw new Error("useGoals must be used within GoalsProvider");
  return ctx;
}