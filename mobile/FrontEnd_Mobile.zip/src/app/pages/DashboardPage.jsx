import React, { useState } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  StyleSheet,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { useGoals } from '../context/GoalsContext';

import { StatCard } from '../components/dashboard/StatCard';
import { GoalListItem } from '../components/dashboard/GoalListItem';
import { GoalDetailView } from '../components/dashboard/GoalDetailView';
import { ConfirmDeleteModal } from '../components/dashboard/ConfirmDeleteModal';

const categoryIcons = {
  Salud:       '❤️',
  Viajes:      '✈️',
  Finanzas:    '💰',
  Personal:    '👤',
  Aprendizaje: '🎓',
};

const categoryColors = {
  Salud:       { main: '#06b6d4', light: '#ecfeff', text: '#0891b2' },
  Viajes:      { main: '#0ea5e9', light: '#f0f9ff', text: '#0369a1' },
  Finanzas:    { main: '#0891b2', light: '#e0f7fa', text: '#0e7490' },
  Personal:    { main: '#0e7490', light: '#cffafe', text: '#155e75' },
  Aprendizaje: { main: '#22d3ee', light: '#f0fdff', text: '#0891b2' },
};

const defaultColor = { main: '#0ea5e9', light: '#f0f9ff', text: '#0369a1' };

function formatDeadline(date) {
  if (!date) return '';
  const d = new Date(date + 'T00:00:00');
  return d.toLocaleDateString('es-ES', { day: '2-digit', month: 'short', year: 'numeric' });
}

function daysLeft(deadline) {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const end = new Date(deadline + 'T00:00:00');
  return Math.ceil((end.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
}

import Layout from '../components/Layout';

export default function DashboardPage() {
  const {
    goals,
    selectedGoalId,
    setSelectedGoalId,
    addMilestone,
    toggleMilestone,
    deleteMilestone,
    deleteGoal,
    user,
  } = useGoals();

  const navigation = useNavigation();
  const [confirmDelete, setConfirmDelete] = useState(null);

  const selectedGoal = goals.find((g) => g.id === selectedGoalId) || null;

  const getProgress = (g) => {
    const milestones = g.milestones || [];
    if (milestones.length === 0) return 0;
    return Math.round(
      (milestones.filter((m) => m.completed).length / milestones.length) * 100
    );
  };

  const handleDeleteGoal = async (goalId) => {
    await deleteGoal(goalId);
    setConfirmDelete(null);
    setSelectedGoalId(null);
  };

  // ── Stats ──
  const totalMilestones     = goals.reduce((acc, g) => acc + (g.milestones?.length || 0), 0);
  const completedMilestones = goals.reduce((acc, g) => acc + (g.milestones?.filter((m) => m.completed).length || 0), 0);
  const completedGoals      = goals.filter((g) => (g.milestones?.length || 0) > 0 && getProgress(g) === 100).length;

  // ── Detail view ──
  if (selectedGoal) {
    return (
      <Layout>
        <ScrollView
          style={styles.flex}
          contentContainerStyle={styles.scrollContent}
          showsVerticalScrollIndicator={false}
        >
          <GoalDetailView
            goal={selectedGoal}
            onBack={() => setSelectedGoalId(null)}
            onDeleteRequest={() => setConfirmDelete(selectedGoal.id)}
            onToggleMilestone={async (mid) => await toggleMilestone(selectedGoal.id, mid)}
            onDeleteMilestone={async (mid) => await deleteMilestone(selectedGoal.id, mid)}
            onAddMilestone={async (text) => await addMilestone(selectedGoal.id, text)}
            categoryIcon={categoryIcons[selectedGoal.category] || '◎'}
            categoryColor={categoryColors[selectedGoal.category] || defaultColor}
            formatDeadline={formatDeadline}
            daysLeft={daysLeft}
            progress={getProgress(selectedGoal)}
          />
        </ScrollView>

        {confirmDelete && (
          <ConfirmDeleteModal
            onConfirm={() => handleDeleteGoal(confirmDelete)}
            onCancel={() => setConfirmDelete(null)}
          />
        )}
      </Layout>
    );
  }

  // ── Overview ──
  return (
    <Layout>
      <ScrollView
        style={styles.flex}
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        {/* Greeting */}
        <View style={styles.greeting}>
          <Text style={styles.greetingTitle}>
            ¡Hola, {user?.name || 'Explorador'} 👋
          </Text>
          <Text style={styles.greetingSubtitle}>
            Revisa tus metas y sigue avanzando hacia el éxito
          </Text>
        </View>

        {/* Stat cards */}
        <View style={styles.statsRow}>
          <StatCard
            label="Metas"
            value={goals.length}
            icon="🎯"
            color="#0ea5e9"
          />
          <StatCard
            label="Hitos"
            value={`${completedMilestones}/${totalMilestones}`}
            icon="✅"
            color="#06b6d4"
          />
          <StatCard
            label="Logradas"
            value={completedGoals}
            icon="🏆"
            color="#0891b2"
          />
        </View>

        {/* Section header */}
        <View style={styles.sectionHeader}>
          <View style={styles.sectionHeaderLeft}>
            <Text style={styles.sparkleIcon}>✨</Text>
            <Text style={styles.sectionTitle}>Mis Metas</Text>
          </View>
          <TouchableOpacity
            onPress={() => navigation.navigate('CreateGoal')}
            style={styles.newGoalButton}
            activeOpacity={0.8}
          >
            <Text style={styles.newGoalButtonText}>＋ Nueva meta</Text>
          </TouchableOpacity>
        </View>

        {/* Empty state */}
        {goals.length === 0 ? (
          <View style={styles.emptyCard}>
            <View style={styles.emptyIconContainer}>
              <Text style={styles.emptyIcon}>🎯</Text>
            </View>
            <Text style={styles.emptyTitle}>Aún no tienes metas</Text>
            <Text style={styles.emptySubtitle}>
              ¡Crea tu primera meta y comienza tu viaje hacia el éxito!
            </Text>
            <TouchableOpacity
              onPress={() => navigation.navigate('CreateGoal')}
              style={styles.emptyButton}
              activeOpacity={0.8}
            >
              <Text style={styles.emptyButtonText}>＋ Crear primera meta</Text>
            </TouchableOpacity>
          </View>
        ) : (
          <View style={styles.goalsList}>
            {goals.map((goal) => (
              <GoalListItem
                key={goal.id}
                goal={goal}
                pct={getProgress(goal)}
                col={categoryColors[goal.category] || defaultColor}
                days={daysLeft(goal.deadline)}
                formatDeadline={formatDeadline}
                onClick={() => setSelectedGoalId(goal.id)}
                categoryIcon={categoryIcons[goal.category] || '◎'}
              />
            ))}

            {/* Add more button */}
            <TouchableOpacity
              onPress={() => navigation.navigate('CreateGoal')}
              style={styles.addMoreButton}
              activeOpacity={0.8}
            >
              <Text style={styles.addMoreText}>＋ Agregar nueva meta</Text>
            </TouchableOpacity>
          </View>
        )}
      </ScrollView>
    </Layout>
  );
}
const styles = StyleSheet.create({
  flex: {
    flex: 1,
  },
  scrollContent: {
    paddingBottom: 32,
  },
  greeting: {
    marginBottom: 20,
  },
  greetingTitle: {
    color: '#0e7490',
    fontWeight: '700',
    fontSize: 22,
  },
  greetingSubtitle: {
    color: '#0891b2',
    fontSize: 14,
    marginTop: 4,
  },
  statsRow: {
    flexDirection: 'row',
    gap: 10,
    marginBottom: 20,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  sectionHeaderLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  sparkleIcon: {
    fontSize: 16,
  },
  sectionTitle: {
    color: '#0e7490',
    fontWeight: '700',
    fontSize: 16,
  },
  newGoalButton: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 12,
    backgroundColor: '#0ea5e9',
  },
  newGoalButtonText: {
    color: 'white',
    fontSize: 13,
    fontWeight: '600',
  },
  emptyCard: {
    borderRadius: 20,
    padding: 40,
    alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.85)',
    borderWidth: 2,
    borderStyle: 'dashed',
    borderColor: 'rgba(14,165,233,0.3)',
  },
  emptyIconContainer: {
    width: 64,
    height: 64,
    borderRadius: 18,
    backgroundColor: '#e0f7fa',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 16,
  },
  emptyIcon: {
    fontSize: 28,
  },
  emptyTitle: {
    color: '#0e7490',
    fontWeight: '700',
    fontSize: 17,
    marginBottom: 8,
  },
  emptySubtitle: {
    color: '#94a3b8',
    fontSize: 14,
    textAlign: 'center',
    lineHeight: 20,
    marginBottom: 20,
  },
  emptyButton: {
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 12,
    backgroundColor: '#0ea5e9',
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    shadowColor: '#0ea5e9',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.35,
    shadowRadius: 10,
    elevation: 4,
  },
  emptyButtonText: {
    color: 'white',
    fontWeight: '700',
    fontSize: 15,
  },
  goalsList: {
    gap: 4,
  },
  addMoreButton: {
    marginTop: 8,
    paddingVertical: 16,
    borderRadius: 16,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(255,255,255,0.6)',
    borderWidth: 2,
    borderStyle: 'dashed',
    borderColor: 'rgba(14,165,233,0.3)',
  },
  addMoreText: {
    color: '#0891b2',
    fontSize: 14,
    fontWeight: '500',
  },
});