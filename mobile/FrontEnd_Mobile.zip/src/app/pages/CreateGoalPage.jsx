import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  ScrollView,
  StyleSheet,
  Platform,
  ActivityIndicator,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { useGoals } from '../context/GoalsContext';
import { CategorySelector } from '../components/create-goal/CategorySelector';
import { generarHitosIA } from '../../services/iaService';
import DateTimePicker from '@react-native-community/datetimepicker';

const CATEGORIES = [
  { id: 'Salud',       label: 'Salud',       icon: '❤️',  color: '#06b6d4', bg: '#ecfeff' },
  { id: 'Viajes',      label: 'Viajes',      icon: '✈️',  color: '#0ea5e9', bg: '#f0f9ff' },
  { id: 'Finanzas',    label: 'Finanzas',    icon: '💰',  color: '#0891b2', bg: '#e0f7fa' },
  { id: 'Personal',    label: 'Personal',    icon: '👤',  color: '#0e7490', bg: '#cffafe' },
  { id: 'Aprendizaje', label: 'Aprendizaje', icon: '🎓',  color: '#67e8f9', bg: '#f0fdff' },
];

const CATEGORY_SUGGESTIONS = {
  Salud: {
    name: 'Ej: Correr 5km, Beber 2L de agua...',
    desc: 'Ej: Mejorar mi condición física y hábitos diarios.',
  },
  Viajes: {
    name: 'Ej: Viajar a Japón, Ahorrar para crucero...',
    desc: 'Ej: Planificar itinerario y reservar vuelos.',
  },
  Finanzas: {
    name: 'Ej: Ahorrar $1000, Pagar tarjeta...',
    desc: 'Ej: Controlar gastos y mejorar mi fondo de ahorro.',
  },
  Personal: {
    name: 'Ej: Leer 12 libros, Meditar diario...',
    desc: 'Ej: Dedicar tiempo a mi crecimiento y bienestar.',
  },
  Aprendizaje: {
    name: 'Ej: Aprender React, Curso de cocina...',
    desc: 'Ej: Adquirir nuevas habilidades prácticas.',
  },
};

import Layout from '../components/Layout';

export default function CreateGoalPage() {
  const { addGoal } = useGoals();
  const navigation = useNavigation();

  const [category,    setCategory]    = useState('');
  const [name,        setName]        = useState('');
  const [description, setDescription] = useState('');
  const [deadline,    setDeadline]    = useState('');
  const [success,     setSuccess]     = useState(false);
  const [loadingIA,   setLoadingIA]   = useState(false);
  const [errors,      setErrors]      = useState({});
  const [formError,   setFormError]   = useState('');

  // Estados para el DatePicker
  const [showDatePicker, setShowDatePicker] = useState(false);
  const [date, setDate] = useState(new Date());

  const validate = () => {
    const e = {};
    if (!name.trim())        e.name        = 'El nombre es requerido';
    if (!description.trim()) e.description = 'La descripción es requerida';
    if (!deadline)           e.deadline    = 'La fecha límite es requerida';
    if (!category)           e.category    = 'Selecciona una categoría';
    return e;
  };

  const handleSubmit = async () => {
    setFormError('');
    const errs = validate();
    setErrors(errs);
    if (Object.keys(errs).length > 0) return;

    try {
      setLoadingIA(true);
      const hitos = await generarHitosIA(name.trim(), description.trim(), deadline);
      setLoadingIA(false);

      const cat = CATEGORIES.find((c) => c.id === category);
      await addGoal({
        nombre:      name.trim(),
        descripcion: description.trim(),
        deadline,
        category,
        color: cat?.color || '#06b6d4',
      }, hitos);

      setSuccess(true);
      setTimeout(() => {
        navigation.navigate('Dashboard');
      }, 2000);
    } catch (err) {
      setLoadingIA(false);
      console.error('Error creating goal:', err);
      const errorCode = err.code || 'unknown';
      setFormError(
        `Error (${errorCode}): No se pudo crear la meta. Revisa las reglas de Firestore.`
      );
    }
  };

  const onDateChange = (event, selectedDate) => {
    setShowDatePicker(false);
    if (selectedDate) {
      setDate(selectedDate);
      // Formatear a YYYY-MM-DD
      const formattedDate = selectedDate.toISOString().split('T')[0];
      setDeadline(formattedDate);
      setErrors((prev) => ({ ...prev, deadline: '' }));
    }
  };

  const currentSuggestions = CATEGORY_SUGGESTIONS[category] || {
    name: 'Ej: Correr 5km, Aprender inglés...',
    desc: 'Describe tu meta en detalle...',
  };

  return (
    <Layout>
      <ScrollView
        style={styles.flex}
        contentContainerStyle={styles.scrollContent}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        {/* Header */}
        <View style={styles.pageHeader}>
          <TouchableOpacity
            onPress={() => navigation.navigate('Dashboard')}
            style={styles.backButton}
            activeOpacity={0.8}
          >
            <Text style={styles.backIcon}>‹</Text>
          </TouchableOpacity>
          <View>
            <Text style={styles.pageTitle}>Crear Nueva Meta</Text>
            <Text style={styles.pageSubtitle}>
              Define tu objetivo y empieza a avanzar
            </Text>
          </View>
        </View>

        {/* Card */}
        <View style={styles.card}>

          {/* Categoría */}
          <View style={styles.fieldGroup}>
            <View style={styles.fieldLabel}>
              <Text style={styles.fieldLabelIcon}>🏷️</Text>
              <Text style={styles.fieldLabelText}>Categoría de la meta</Text>
            </View>
            <CategorySelector
              categories={CATEGORIES}
              selectedId={category}
              onSelect={(id) => {
                setCategory(id);
                setErrors((prev) => ({ ...prev, category: '' }));
              }}
            />
            {errors.category && (
              <Text style={styles.errorText}>{errors.category}</Text>
            )}
          </View>

          <View style={styles.divider} />

          {/* Nombre */}
          <View style={styles.fieldGroup}>
            <View style={styles.fieldLabel}>
              <Text style={styles.fieldLabelIcon}>✨</Text>
              <Text style={styles.fieldLabelText}>Nombre de la meta</Text>
            </View>
            <TextInput
              value={name}
              onChangeText={(v) => {
                setName(v);
                setErrors((prev) => ({ ...prev, name: '' }));
              }}
              placeholder={currentSuggestions.name}
              placeholderTextColor="#94a3b8"
              style={[styles.input, errors.name && styles.inputError]}
            />
            {errors.name && (
              <Text style={styles.errorText}>{errors.name}</Text>
            )}
          </View>

          {/* Descripción */}
          <View style={styles.fieldGroup}>
            <View style={styles.fieldLabel}>
              <Text style={styles.fieldLabelIcon}>📄</Text>
              <Text style={styles.fieldLabelText}>Descripción</Text>
            </View>
            <TextInput
              value={description}
              onChangeText={(v) => {
                setDescription(v);
                setErrors((prev) => ({ ...prev, description: '' }));
              }}
              placeholder={currentSuggestions.desc}
              placeholderTextColor="#94a3b8"
              multiline
              numberOfLines={3}
              style={[styles.input, styles.textArea, errors.description && styles.inputError]}
            />
            {errors.description && (
              <Text style={styles.errorText}>{errors.description}</Text>
            )}
          </View>

          {/* Fecha límite */}
          <View style={styles.fieldGroup}>
            <View style={styles.fieldLabel}>
              <Text style={styles.fieldLabelIcon}>📅</Text>
              <Text style={styles.fieldLabelText}>Fecha límite</Text>
            </View>
            <TouchableOpacity
              onPress={() => setShowDatePicker(true)}
              activeOpacity={0.7}
              style={[styles.input, styles.dateButton, errors.deadline && styles.inputError]}
            >
              <Text style={[styles.dateButtonText, !deadline && styles.placeholderText]}>
                {deadline || 'Selecciona la fecha límite...'}
              </Text>
              <Text style={styles.calendarIcon}>📅</Text>
            </TouchableOpacity>
            
            {showDatePicker && (
              <DateTimePicker
                value={date}
                mode="date"
                display={Platform.OS === 'ios' ? 'spinner' : 'default'}
                onChange={onDateChange}
                minimumDate={new Date()}
              />
            )}
            
            {errors.deadline && (
              <Text style={styles.errorText}>{errors.deadline}</Text>
            )}
          </View>

          {/* Loading IA */}
          {loadingIA && (
            <View style={styles.loadingIABox}>
              <ActivityIndicator color="#0ea5e9" size="small" />
              <Text style={styles.loadingIAText}>Generando hitos inteligentes...</Text>
            </View>
          )}

          {/* Form error */}
          {formError !== '' && (
            <View style={styles.formErrorBox}>
              <Text style={styles.formErrorText}>{formError}</Text>
            </View>
          )}

          {/* Success message */}
          {success && (
            <View style={styles.successBox}>
              <Text style={styles.successTitle}>✅ ¡Meta creada con éxito!</Text>
              <Text style={styles.successSub}>Volviendo al dashboard...</Text>
            </View>
          )}

          {/* Submit button */}
          <TouchableOpacity
            onPress={handleSubmit}
            disabled={success || loadingIA}
            activeOpacity={0.9}
            style={[
              styles.submitButton,
              (success || loadingIA) && styles.submitButtonDisabled,
              success && styles.submitButtonSuccess,
            ]}
          >
            <Text style={styles.submitText}>
              {success ? '✅ ¡Meta creada!' : loadingIA ? 'Generando...' : '✨ Crear Meta'}
            </Text>
          </TouchableOpacity>

        </View>
      </ScrollView>
    </Layout>
  );
}

const styles = StyleSheet.create({
  flex: {
    flex: 1,
  },
  scrollContent: {
    paddingBottom: 40,
  },
  pageHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginBottom: 20,
  },
  backButton: {
    width: 36,
    height: 36,
    borderRadius: 10,
    backgroundColor: 'rgba(14,165,233,0.1)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  backIcon: {
    fontSize: 24,
    color: '#0891b2',
    lineHeight: 28,
  },
  pageTitle: {
    color: '#0e7490',
    fontWeight: '700',
    fontSize: 20,
  },
  pageSubtitle: {
    color: '#0891b2',
    fontSize: 13,
    marginTop: 2,
  },
  card: {
    borderRadius: 20,
    padding: 24,
    backgroundColor: 'rgba(255,255,255,0.85)',
    borderWidth: 1,
    borderColor: 'rgba(14,165,233,0.15)',
    shadowColor: '#0ea5e9',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.12,
    shadowRadius: 12,
    elevation: 4,
    gap: 20,
  },
  fieldGroup: {
    gap: 8,
  },
  fieldLabel: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  fieldLabelIcon: {
    fontSize: 15,
  },
  fieldLabelText: {
    color: '#0e7490',
    fontSize: 15,
  },
  input: {
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderRadius: 12,
    backgroundColor: '#f0f9ff',
    borderWidth: 2,
    borderColor: 'rgba(14,165,233,0.2)',
    color: '#0e7490',
    fontSize: 15,
  },
  dateButton: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  dateButtonText: {
    color: '#0e7490',
    fontSize: 15,
  },
  placeholderText: {
    color: '#94a3b8',
  },
  calendarIcon: {
    fontSize: 16,
    opacity: 0.7,
  },
  inputError: {
    borderColor: '#ef4444',
  },
  textArea: {
    minHeight: 88,
    textAlignVertical: 'top',
  },
  errorText: {
    color: '#ef4444',
    fontSize: 12,
    marginTop: 2,
  },
  divider: {
    height: 1,
    backgroundColor: 'rgba(14,165,233,0.12)',
  },
  loadingIABox: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    padding: 12,
    borderRadius: 12,
    backgroundColor: 'rgba(14,165,233,0.05)',
  },
  loadingIAText: {
    color: '#0ea5e9',
    fontSize: 14,
    fontStyle: 'italic',
  },
  formErrorBox: {
    padding: 12,
    borderRadius: 12,
    backgroundColor: 'rgba(239,68,68,0.1)',
  },
  formErrorText: {
    color: '#ef4444',
    fontSize: 14,
    textAlign: 'center',
  },
  successBox: {
    padding: 16,
    borderRadius: 12,
    backgroundColor: 'rgba(34,197,94,0.1)',
    borderWidth: 1,
    borderColor: 'rgba(34,197,94,0.2)',
    alignItems: 'center',
    gap: 4,
  },
  successTitle: {
    color: '#16a34a',
    fontWeight: '700',
    fontSize: 15,
  },
  successSub: {
    color: '#16a34a',
    fontSize: 13,
    opacity: 0.8,
  },
  submitButton: {
    paddingVertical: 16,
    borderRadius: 12,
    backgroundColor: '#0ea5e9',
    alignItems: 'center',
    shadowColor: '#0ea5e9',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.35,
    shadowRadius: 10,
    elevation: 4,
  },
  submitButtonDisabled: {
    opacity: 0.6,
  },
  submitButtonSuccess: {
    backgroundColor: '#22c55e',
    opacity: 0.8,
  },
  submitText: {
    color: 'white',
    fontWeight: '700',
    fontSize: 16,
  },
});