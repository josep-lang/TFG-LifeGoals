import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { View, ActivityIndicator, StyleSheet } from 'react-native';
import { useGoals } from './context/GoalsContext';

import LoginPage from './pages/LoginPage';
import DashboardPage from './pages/DashboardPage';
import CreateGoalPage from './pages/CreateGoalPage';

const Stack = createNativeStackNavigator();

function LoadingScreen() {
  return (
    <View style={styles.loadingContainer}>
      <ActivityIndicator size="large" color="#0891b2" />
    </View>
  );
}

function AppNavigator() {
  const { user, loading } = useGoals();

  if (loading) return <LoadingScreen />;

  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      {!user ? (
        // Guest routes
        <Stack.Screen name="Login" component={LoginPage} />
      ) : (
        // Protected routes
        <>
          <Stack.Screen name="Dashboard" component={DashboardPage} />
          <Stack.Screen name="CreateGoal" component={CreateGoalPage} />
        </>
      )}
    </Stack.Navigator>
  );
}

export default function Routes() {
  return (
    <NavigationContainer>
      <AppNavigator />
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#ecfeff',
  },
});