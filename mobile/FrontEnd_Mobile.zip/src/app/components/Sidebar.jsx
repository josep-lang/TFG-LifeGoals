import React from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  StyleSheet,
  Modal,
  Animated,
  Dimensions,
  Image,
} from 'react-native';
import { useNavigation, useRoute } from '@react-navigation/native';
import { useGoals } from '../context/GoalsContext';

const { width } = Dimensions.get('window');

const categoryEmojis = {
  Salud:       '❤️',
  Viajes:      '✈️',
  Finanzas:    '💰',
  Personal:    '👤',
  Aprendizaje: '🎓',
};

export default function Sidebar({ open, onClose }) {
  const { goals, selectedGoalId, setSelectedGoalId, user, logout } = useGoals();
  const navigation = useNavigation();
  const route = useRoute();

  const handleGoalClick = (id) => {
    setSelectedGoalId(id);
    navigation.navigate('Dashboard');
    onClose();
  };

  const handleLogout = async () => {
    await logout();
    onClose();
  };

  const progress = (g) => {
    if (g.milestones.length === 0) return 0;
    return Math.round(
      (g.milestones.filter((m) => m.completed).length / g.milestones.length) * 100
    );
  };

  return (
    <Modal
      visible={open}
      transparent
      animationType="none"
      onRequestClose={onClose}
    >
      {/* Overlay */}
      <TouchableOpacity
        style={styles.overlay}
        activeOpacity={1}
        onPress={onClose}
      />

      {/* Sidebar panel */}
      <View style={styles.sidebar}>

        {/* Header */}
        <View style={styles.sidebarHeader}>
          <View style={styles.brandRow}>
            <Image 
              source={require('./ui/Lifegoals.png')} 
              style={{ width: 40, height: 40, borderRadius: 8 }}
              resizeMode="contain"
            />
            <View>
              <Text style={styles.brandName}>Life Goals</Text>
              {user && (
                <Text style={styles.brandUser}>{user.name}</Text>
              )}
            </View>
          </View>
          <TouchableOpacity onPress={onClose} style={styles.closeButton}>
            <Text style={styles.closeText}>✕</Text>
          </TouchableOpacity>
        </View>

        <View style={styles.divider} />

        {/* Nav links */}
        <View style={styles.navLinks}>
          <TouchableOpacity
            style={[
              styles.navItem,
              route.name === 'Dashboard' && styles.navItemActive,
            ]}
            onPress={() => { navigation.navigate('Dashboard'); onClose(); }}
          >
            <Text style={styles.navIcon}>🏠</Text>
            <Text style={styles.navText}>Inicio</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[
              styles.navItem,
              route.name === 'CreateGoal' && styles.navItemActive,
            ]}
            onPress={() => { navigation.navigate('CreateGoal'); onClose(); }}
          >
            <Text style={styles.navIcon}>＋</Text>
            <Text style={styles.navText}>Nueva Meta</Text>
          </TouchableOpacity>
        </View>

        <View style={styles.divider} />

        {/* Goals label */}
        <View style={styles.goalsLabel}>
          <Text style={styles.goalsLabelText}>
            ★ MIS METAS ({goals.length})
          </Text>
        </View>

        {/* Goals list */}
        <ScrollView
          style={styles.goalsList}
          showsVerticalScrollIndicator={false}
        >
          {goals.length === 0 && (
            <View style={styles.emptyGoals}>
              <Text style={styles.emptyGoalsText}>
                Aún no tienes metas. ¡Crea la primera!
              </Text>
            </View>
          )}

          {goals.map((goal) => {
            const pct = progress(goal);
            const isSelected = goal.id === selectedGoalId;
            return (
              <TouchableOpacity
                key={goal.id}
                onPress={() => handleGoalClick(goal.id)}
                style={[styles.goalItem, isSelected && styles.goalItemSelected]}
                activeOpacity={0.8}
              >
                <View style={styles.goalItemIcon}>
                  <Text style={{ fontSize: 14 }}>
                    {categoryEmojis[goal.category] || '◎'}
                  </Text>
                </View>
                <View style={styles.goalItemContent}>
                  <Text style={styles.goalItemName} numberOfLines={1}>
                    {goal.nombre}
                  </Text>
                  <View style={styles.progressRow}>
                    <View style={styles.progressBar}>
                      <View
                        style={[
                          styles.progressFill,
                          {
                            width: `${pct}%`,
                            backgroundColor: pct === 100 ? '#4ade80' : 'rgba(255,255,255,0.8)',
                          },
                        ]}
                      />
                    </View>
                    <Text style={styles.progressText}>{pct}%</Text>
                  </View>
                </View>
              </TouchableOpacity>
            );
          })}
        </ScrollView>

        {/* Footer - Logout */}
        <View style={styles.footer}>
          <View style={styles.divider} />
          <TouchableOpacity
            onPress={handleLogout}
            style={styles.logoutButton}
            activeOpacity={0.7}
          >
            <Text style={styles.logoutIcon}>⎋</Text>
            <Text style={styles.logoutText}>Cerrar sesión</Text>
          </TouchableOpacity>
        </View>

      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: {
    position: 'absolute',
    top: 0, left: 0, right: 0, bottom: 0,
    backgroundColor: 'rgba(0,0,0,0.4)',
  },
  sidebar: {
    position: 'absolute',
    top: 0,
    left: 0,
    bottom: 0,
    width: 280,
    backgroundColor: '#0e7490',
    shadowColor: '#000',
    shadowOffset: { width: 4, height: 0 },
    shadowOpacity: 0.2,
    shadowRadius: 12,
    elevation: 10,
  },
  sidebarHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingTop: 52,
    paddingBottom: 20,
  },
  brandRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  brandIcon: {
    width: 40,
    height: 40,
    borderRadius: 12,
    backgroundColor: 'rgba(255,255,255,0.2)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  brandIconText: {
    fontSize: 20,
    color: 'white',
  },
  brandName: {
    color: 'white',
    fontWeight: '700',
    fontSize: 16,
  },
  brandUser: {
    color: 'rgba(255,255,255,0.65)',
    fontSize: 12,
  },
  closeButton: {
    width: 32,
    height: 32,
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(255,255,255,0.1)',
  },
  closeText: {
    color: 'rgba(255,255,255,0.7)',
    fontSize: 14,
  },
  divider: {
    height: 1,
    backgroundColor: 'rgba(255,255,255,0.15)',
    marginHorizontal: 12,
    marginVertical: 8,
  },
  navLinks: {
    paddingHorizontal: 12,
    gap: 4,
  },
  navItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    paddingHorizontal: 12,
    paddingVertical: 10,
    borderRadius: 12,
  },
  navItemActive: {
    backgroundColor: 'rgba(255,255,255,0.2)',
  },
  navIcon: {
    fontSize: 16,
  },
  navText: {
    color: 'white',
    fontSize: 14,
  },
  goalsLabel: {
    paddingHorizontal: 20,
    marginBottom: 6,
  },
  goalsLabelText: {
    color: 'rgba(255,255,255,0.5)',
    fontSize: 11,
    letterSpacing: 1,
  },
  goalsList: {
    flex: 1,
    paddingHorizontal: 12,
  },
  emptyGoals: {
    paddingVertical: 32,
    paddingHorizontal: 16,
    alignItems: 'center',
  },
  emptyGoalsText: {
    color: 'rgba(255,255,255,0.4)',
    fontSize: 13,
    textAlign: 'center',
  },
  goalItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingHorizontal: 12,
    paddingVertical: 10,
    borderRadius: 12,
    marginBottom: 6,
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderWidth: 1,
    borderColor: 'transparent',
  },
  goalItemSelected: {
    backgroundColor: 'rgba(255,255,255,0.22)',
    borderColor: 'rgba(255,255,255,0.35)',
  },
  goalItemIcon: {
    width: 28,
    height: 28,
    borderRadius: 8,
    backgroundColor: 'rgba(255,255,255,0.2)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  goalItemContent: {
    flex: 1,
  },
  goalItemName: {
    color: 'white',
    fontSize: 13,
    fontWeight: '600',
  },
  progressRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginTop: 4,
  },
  progressBar: {
    flex: 1,
    height: 4,
    borderRadius: 2,
    backgroundColor: 'rgba(255,255,255,0.2)',
    overflow: 'hidden',
  },
  progressFill: {
    height: 4,
    borderRadius: 2,
  },
  progressText: {
    color: 'rgba(255,255,255,0.6)',
    fontSize: 11,
  },
  footer: {
    paddingHorizontal: 12,
    paddingBottom: 32,
  },
  logoutButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    paddingHorizontal: 12,
    paddingVertical: 10,
    borderRadius: 12,
  },
  logoutIcon: {
    fontSize: 16,
    color: 'rgba(255,255,255,0.7)',
  },
  logoutText: {
    color: 'rgba(255,255,255,0.7)',
    fontSize: 14,
  },
});