import React from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
} from 'react-native';

export function CategorySelector({ categories, selectedId, onSelect }) {
  return (
    <View style={styles.grid}>
      {categories.map((cat) => {
        const selected = selectedId === cat.id;
        return (
          <TouchableOpacity
            key={cat.id}
            onPress={() => onSelect(cat.id)}
            activeOpacity={0.8}
            style={[
              styles.categoryButton,
              {
                backgroundColor: selected ? cat.color : cat.bg,
                borderColor: selected ? cat.color : 'transparent',
                shadowColor: selected ? cat.color : 'transparent',
                shadowOpacity: selected ? 0.3 : 0,
                elevation: selected ? 4 : 0,
              },
            ]}
          >
            <Text style={styles.categoryIcon}>{cat.icon}</Text>
            <Text
              style={[
                styles.categoryLabel,
                { color: selected ? 'white' : cat.color },
              ]}
            >
              {cat.label}
            </Text>
          </TouchableOpacity>
        );
      })}
    </View>
  );
}

const styles = StyleSheet.create({
  grid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    justifyContent: 'space-between',
  },
  categoryButton: {
    width: '18%',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    paddingHorizontal: 4,
    borderRadius: 12,
    borderWidth: 2,
    shadowOffset: { width: 0, height: 4 },
    shadowRadius: 8,
  },
  categoryIcon: {
    fontSize: 18,
    marginBottom: 4,
  },
  categoryLabel: {
    fontSize: 11,
    fontWeight: '600',
    textAlign: 'center',
  },
});