import React, { useState } from 'react';
import {
  View,
  Text,
  Modal,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  ActivityIndicator,
  Alert,
} from 'react-native';
import { useGoals } from '../context/GoalsContext';

export function ProfileModal({ visible, onClose }) {
  const { user, updateUserName, updateUserPassword, reauthenticate } = useGoals();
  
  const [newName, setNewName] = useState(user?.name || '');
  const [currentPass, setCurrentPass] = useState('');
  const [newPass, setNewPass] = useState('');
  const [confirmPass, setConfirmPass] = useState('');
  
  const [loadingName, setLoadingName] = useState(false);
  const [loadingPass, setLoadingPass] = useState(false);

  const handleUpdateName = async () => {
    if (!newName.trim()) return;
    setLoadingName(true);
    const success = await updateUserName(newName.trim());
    setLoadingName(false);
    if (success) {
      Alert.alert('Éxito', 'Nombre actualizado correctamente');
    } else {
      Alert.alert('Error', 'No se pudo actualizar el nombre');
    }
  };

  const handleChangePassword = async () => {
    // Validaciones
    if (!currentPass) {
      Alert.alert('Error', 'Debes introducir tu contraseña antigua');
      return;
    }
    if (!newPass || newPass.length < 6) {
      Alert.alert('Error', 'La nueva contraseña debe tener al menos 6 caracteres');
      return;
    }
    if (newPass !== confirmPass) {
      Alert.alert('Error', 'Las contraseñas nuevas no coinciden');
      return;
    }

    setLoadingPass(true);

    // 1. Reautenticar
    const isAuth = await reauthenticate(currentPass);
    if (!isAuth) {
      setLoadingPass(false);
      Alert.alert('Error', 'La contraseña antigua no es correcta');
      return;
    }

    // 2. Cambiar contraseña
    const success = await updateUserPassword(newPass);
    setLoadingPass(false);

    if (success) {
      setCurrentPass('');
      setNewPass('');
      setConfirmPass('');
      Alert.alert('Éxito', 'Contraseña actualizada correctamente');
    } else {
      Alert.alert('Error', 'No se pudo actualizar la contraseña');
    }
  };

  return (
    <Modal
      visible={visible}
      transparent
      animationType="fade"
      onRequestClose={onClose}
    >
      <View style={styles.overlay}>
        <View style={styles.card}>
          <View style={styles.header}>
            <Text style={styles.title}>Ajustes de Perfil</Text>
            <TouchableOpacity onPress={onClose} style={styles.closeBtn}>
              <Text style={styles.closeText}>✕</Text>
            </TouchableOpacity>
          </View>

          {/* Cambiar Nombre */}
          <View style={styles.section}>
            <Text style={styles.label}>Nombre de Usuario</Text>
            <TextInput
              value={newName}
              onChangeText={setNewName}
              style={styles.input}
              placeholder="Nuevo nombre"
            />
            <TouchableOpacity
              onPress={handleUpdateName}
              style={[styles.button, { backgroundColor: '#0ea5e9' }]}
              disabled={loadingName}
            >
              {loadingName ? (
                <ActivityIndicator color="white" size="small" />
              ) : (
                <Text style={styles.buttonText}>Actualizar Nombre</Text>
              )}
            </TouchableOpacity>
          </View>

          <View style={styles.divider} />

          {/* Cambiar Contraseña */}
          <View style={styles.section}>
            <Text style={styles.label}>Seguridad de la Cuenta</Text>
            
            <TextInput
              value={currentPass}
              onChangeText={setCurrentPass}
              style={styles.input}
              placeholder="Contraseña ANTIGUA"
              secureTextEntry
              placeholderTextColor="#000"
            />

            <View style={styles.innerDivider} />

            <TextInput
              value={newPass}
              onChangeText={setNewPass}
              style={styles.input}
              placeholder="Contraseña NUEVA"
              secureTextEntry
              placeholderTextColor="#000"
            />
            <TextInput
              value={confirmPass}
              onChangeText={setConfirmPass}
              style={styles.input}
              placeholder="Confirmar contraseña NUEVA"
              secureTextEntry
              placeholderTextColor="#000"
            />

            <TouchableOpacity
              onPress={handleChangePassword}
              style={[styles.button, { backgroundColor: '#0891b2' }]}
              disabled={loadingPass}
            >
              {loadingPass ? (
                <ActivityIndicator color="white" size="small" />
              ) : (
                <Text style={styles.buttonText}>Cambiar Contraseña</Text>
              )}
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    padding: 20,
  },
  card: {
    backgroundColor: 'white',
    borderRadius: 20,
    padding: 24,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 10 },
    shadowOpacity: 0.1,
    shadowRadius: 10,
    elevation: 5,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  title: {
    fontSize: 20,
    fontWeight: '700',
    color: '#0e7490',
  },
  closeBtn: {
    padding: 4,
  },
  closeText: {
    fontSize: 20,
    color: '#94a3b8',
  },
  section: {
    marginBottom: 16,
  },
  label: {
    fontSize: 14,
    fontWeight: '600',
    color: '#64748b',
    marginBottom: 8,
  },
  input: {
    backgroundColor: '#f8fafc',
    borderWidth: 1,
    borderColor: '#1e293b',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
    marginBottom: 12,
    fontSize: 15,
    color: '#1e293b',
  },
  innerDivider: {
    height: 1,
    backgroundColor: '#f1f5f9',
    marginVertical: 8,
  },
  button: {
    paddingVertical: 14,
    borderRadius: 12,
    alignItems: 'center',
  },
  buttonText: {
    color: 'white',
    fontWeight: '700',
    fontSize: 15,
  },
  divider: {
    height: 1,
    backgroundColor: '#1e293b',
    marginVertical: 16,
  },
});