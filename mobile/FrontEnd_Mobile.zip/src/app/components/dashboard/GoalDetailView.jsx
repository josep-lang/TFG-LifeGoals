import React, { useState } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  TextInput,
  ScrollView,
  StyleSheet,
} from 'react-native';
import { MilestoneItem } from './MilestoneItem';

export function GoalDetailView({
  goal,
  onBack,
  onDeleteRequest,
  onToggleMilestone,
  onDeleteMilestone,
  onAddMilestone,
  categoryIcon,
  categoryColor,
  formatDeadline,
  daysLeft,
  progress,
}) {
  const [newMilestone, setNewMilestone] = useState('');
  const [addingMilestone, setAddingMilestone] = useState(false);

  const days = daysLeft(goal.deadline);
  const completedCount = goal.milestones.filter((m) => m.completed).length;

  const handleSubmit = () => {
    if (!newMilestone.trim()) return;
    onAddMilestone(newMilestone.trim());
    setNewMilestone('');
    setAddingMilestone(false);
  };

  return (
    <ScrollView showsVerticalScrollIndicator={false}>

      {/* Back button */}
      <TouchableOpacity
        onPress={onBack}
        style={styles.backButton}
        activeOpacity={0.7}
      >
        <Text style={styles.backIcon}>‹</Text>
        <Text style={styles.backText}>Todas las metas</Text>
      </TouchableOpacity>

      {/* Hero card */}
      <View style={[styles.heroCard, { backgroundColor: categoryColor.main }]}>

        {/* Decorative blobs */}
        <View style={styles.blobTopRight} pointerEvents="none" />
        <View style={styles.blobBottomLeft} pointerEvents="none" />

        {/* Header row */}
        <View style={styles.heroHeader}>
          <View style={styles.heroHeaderLeft}>
            <View style={styles.heroIconContainer}>
              <Text style={styles.heroIcon}>{categoryIcon}</Text>
            </View>
            <View style={styles.categoryBadge}>
              <Text style={styles.categoryBadgeText}>
                {goal.category.charAt(0).toUpperCase() + goal.category.slice(1)}
              </Text>
            </View>
          </View>
          <TouchableOpacity
            onPress={onDeleteRequest}
            style={styles.deleteButton}
            activeOpacity={0.7}
          >
            <Text style={styles.deleteIcon}>🗑</Text>
          </TouchableOpacity>
        </View>

        {/* Title & description */}
        <Text style={styles.heroTitle}>{goal.nombre}</Text>
        <Text style={styles.heroDesc}>{goal.descripcion}</Text>

        {/* Deadline row */}
        <View style={styles.deadlineRow}>
          <Text style={styles.deadlineIcon}>📅</Text>
          <Text style={styles.deadlineText}>
            Límite: {formatDeadline(goal.deadline)}
          </Text>
          {days >= 0 ? (
            <View style={styles.daysBadge}>
              <Text style={styles.daysBadgeText}>
                {days === 0 ? '¡Hoy!' : `${days}d restantes`}
              </Text>
            </View>
          ) : (
            <View style={styles.expiredBadge}>
              <Text style={styles.expiredBadgeText}>Vencida</Text>
            </View>
          )}
        </View>

        {/* Progress */}
        <View style={styles.progressSection}>
          <View style={styles.progressLabels}>
            <Text style={styles.progressLabelLeft}>
              {completedCount}/{goal.milestones.length} hitos completados
            </Text>
            <Text style={styles.progressLabelRight}>{progress}%</Text>
          </View>
          <View style={styles.progressBarBg}>
            <View
              style={[
                styles.progressBarFill,
                {
                  width: `${progress}%`,
                  backgroundColor: progress === 100 ? '#4ade80' : 'white',
                },
              ]}
            />
          </View>
        </View>
      </View>

      {/* Milestones card */}
      <View style={styles.milestonesCard}>

        {/* Milestones header */}
        <View style={styles.milestonesHeader}>
          <View style={styles.milestonesHeaderLeft}>
            <Text style={[styles.flagIcon, { color: categoryColor.main }]}>⚑</Text>
            <Text style={styles.milestonesTitle}>Hitos</Text>
          </View>
          <TouchableOpacity
            onPress={() => setAddingMilestone((v) => !v)}
            style={[
              styles.addButton,
              addingMilestone
                ? styles.addButtonCancel
                : { backgroundColor: categoryColor.main },
            ]}
            activeOpacity={0.8}
          >
            <Text style={[
              styles.addButtonText,
              addingMilestone && styles.addButtonTextCancel,
            ]}>
              {addingMilestone ? '✕ Cancelar' : '＋ Añadir hito'}
            </Text>
          </TouchableOpacity>
        </View>

        {/* Add milestone input */}
        {addingMilestone && (
          <View style={styles.addMilestoneRow}>
            <TextInput
              autoFocus
              value={newMilestone}
              onChangeText={setNewMilestone}
              placeholder="Describe el hito a alcanzar..."
              placeholderTextColor="#94a3b8"
              style={styles.milestoneInput}
              onSubmitEditing={handleSubmit}
              returnKeyType="done"
            />
            <TouchableOpacity
              onPress={handleSubmit}
              style={[styles.submitButton, { backgroundColor: categoryColor.main }]}
              activeOpacity={0.8}
            >
              <Text style={styles.submitButtonText}>Añadir</Text>
            </TouchableOpacity>
          </View>
        )}

        {/* Milestones list */}
        {goal.milestones.length === 0 ? (
          <View style={styles.emptyMilestones}>
            <View style={styles.emptyIconContainer}>
              <Text style={styles.emptyIcon}>⚑</Text>
            </View>
            <Text style={styles.emptyText}>
              Aún no tienes hitos. ¡Añade el primero!
            </Text>
          </View>
        ) : (
          <View style={styles.milestonesList}>
            {goal.milestones.map((milestone) => (
              <MilestoneItem
                key={milestone.id}
                milestone={milestone}
                onToggle={() => onToggleMilestone(milestone.id)}
                onDelete={() => onDeleteMilestone(milestone.id)}
              />
            ))}
          </View>
        )}

        {/* Completed banner */}
        {progress === 100 && goal.milestones.length > 0 && (
          <View style={styles.completedBanner}>
            <Text style={styles.completedTrophy}>🏆</Text>
            <Text style={styles.completedTitle}>¡Meta completada! 🎉</Text>
            <Text style={styles.completedSub}>Has alcanzado todos tus hitos</Text>
          </View>
        )}

      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  backButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    marginBottom: 20,
  },
  backIcon: {
    fontSize: 22,
    color: '#0891b2',
    lineHeight: 24,
  },
  backText: {
    color: '#0891b2',
    fontSize: 14,
  },

  // Hero card
  heroCard: {
    borderRadius: 20,
    padding: 20,
    marginBottom: 16,
    overflow: 'hidden',
    shadowColor: '#0ea5e9',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.3,
    shadowRadius: 16,
    elevation: 6,
  },
  blobTopRight: {
    position: 'absolute',
    top: -30,
    right: -30,
    width: 140,
    height: 140,
    borderRadius: 70,
    backgroundColor: 'rgba(255,255,255,0.15)',
  },
  blobBottomLeft: {
    position: 'absolute',
    bottom: -20,
    left: -20,
    width: 100,
    height: 100,
    borderRadius: 50,
    backgroundColor: 'rgba(255,255,255,0.10)',
  },
  heroHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  heroHeaderLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  heroIconContainer: {
    width: 40,
    height: 40,
    borderRadius: 12,
    backgroundColor: 'rgba(255,255,255,0.25)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  heroIcon: {
    fontSize: 20,
    color: 'white',
  },
  categoryBadge: {
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 20,
    backgroundColor: 'rgba(255,255,255,0.2)',
  },
  categoryBadgeText: {
    color: 'white',
    fontSize: 12,
    fontWeight: '600',
  },
  deleteButton: {
    width: 32,
    height: 32,
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(255,255,255,0.15)',
  },
  deleteIcon: {
    fontSize: 15,
  },
  heroTitle: {
    color: 'white',
    fontWeight: '700',
    fontSize: 22,
    marginBottom: 4,
  },
  heroDesc: {
    color: 'rgba(255,255,255,0.8)',
    fontSize: 14,
    lineHeight: 20,
  },
  deadlineRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginTop: 12,
  },
  deadlineIcon: {
    fontSize: 13,
  },
  deadlineText: {
    color: 'rgba(255,255,255,0.7)',
    fontSize: 13,
  },
  daysBadge: {
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 20,
    backgroundColor: 'rgba(255,255,255,0.18)',
  },
  daysBadgeText: {
    color: 'white',
    fontSize: 11,
  },
  expiredBadge: {
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 20,
    backgroundColor: 'rgba(239,68,68,0.35)',
  },
  expiredBadgeText: {
    color: 'white',
    fontSize: 11,
  },
  progressSection: {
    marginTop: 16,
  },
  progressLabels: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 6,
  },
  progressLabelLeft: {
    color: 'rgba(255,255,255,0.75)',
    fontSize: 12,
  },
  progressLabelRight: {
    color: 'white',
    fontSize: 12,
    fontWeight: '700',
  },
  progressBarBg: {
    width: '100%',
    height: 10,
    borderRadius: 5,
    backgroundColor: 'rgba(255,255,255,0.2)',
    overflow: 'hidden',
  },
  progressBarFill: {
    height: 10,
    borderRadius: 5,
  },

  // Milestones card
  milestonesCard: {
    borderRadius: 20,
    padding: 20,
    backgroundColor: 'rgba(255,255,255,0.88)',
    borderWidth: 1,
    borderColor: 'rgba(14,165,233,0.12)',
    shadowColor: '#0ea5e9',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.10,
    shadowRadius: 12,
    elevation: 3,
    marginBottom: 24,
  },
  milestonesHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  milestonesHeaderLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  flagIcon: {
    fontSize: 16,
  },
  milestonesTitle: {
    color: '#0e7490',
    fontWeight: '700',
    fontSize: 16,
  },
  addButton: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 12,
  },
  addButtonCancel: {
    backgroundColor: 'rgba(14,165,233,0.15)',
  },
  addButtonText: {
    color: 'white',
    fontSize: 13,
    fontWeight: '600',
  },
  addButtonTextCancel: {
    color: '#0891b2',
  },
  addMilestoneRow: {
    flexDirection: 'row',
    gap: 8,
    marginBottom: 16,
  },
  milestoneInput: {
    flex: 1,
    paddingHorizontal: 12,
    paddingVertical: 10,
    borderRadius: 12,
    backgroundColor: '#f0f9ff',
    borderWidth: 2,
    borderColor: 'rgba(14,165,233,0.25)',
    color: '#0e7490',
    fontSize: 14,
  },
  submitButton: {
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  submitButtonText: {
    color: 'white',
    fontSize: 14,
    fontWeight: '600',
  },
  milestonesList: {
    gap: 8,
  },
  emptyMilestones: {
    alignItems: 'center',
    paddingVertical: 40,
  },
  emptyIconContainer: {
    width: 56,
    height: 56,
    borderRadius: 16,
    backgroundColor: '#f0f9ff',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 12,
  },
  emptyIcon: {
    fontSize: 24,
    color: '#7dd3fc',
  },
  emptyText: {
    color: '#94a3b8',
    fontSize: 14,
  },
  completedBanner: {
    marginTop: 16,
    padding: 16,
    borderRadius: 12,
    backgroundColor: '#f0fdf4',
    borderWidth: 1,
    borderColor: '#bbf7d0',
    alignItems: 'center',
  },
  completedTrophy: {
    fontSize: 28,
    marginBottom: 6,
  },
  completedTitle: {
    color: '#16a34a',
    fontWeight: '700',
    fontSize: 15,
  },
  completedSub: {
    color: '#4ade80',
    fontSize: 13,
    marginTop: 2,
  },
});