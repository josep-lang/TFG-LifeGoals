import React from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
} from 'react-native';

export function GoalListItem({
  goal,
  pct,
  col,
  days,
  formatDeadline,
  onClick,
  categoryIcon,
}) {
  const completedCount = goal.milestones.filter((m) => m.completed).length;
  const totalCount = goal.milestones.length;

  const deadlineBadge = () => {
    if (days < 0) {
      return (
        <View style={styles.badgeRed}>
          <Text style={styles.badgeRedText}>Vencida</Text>
        </View>
      );
    }
    if (days <= 7) {
      return (
        <View style={styles.badgeOrange}>
          <Text style={styles.badgeOrangeText}>
            {days === 0 ? '¡Hoy!' : `${days}d`}
          </Text>
        </View>
      );
    }
    return (
      <View style={[styles.badgeDefault, { backgroundColor: col.light }]}>
        <Text style={[styles.badgeDefaultText, { color: col.text }]}>
          {days}d restantes
        </Text>
      </View>
    );
  };

  return (
    <TouchableOpacity
      onPress={onClick}
      activeOpacity={0.95}
      style={styles.card}
    >
      <View style={styles.row}>

        {/* Category icon */}
        <View style={[styles.iconContainer, { backgroundColor: col.main }]}>
          <Text style={styles.iconText}>{categoryIcon}</Text>
        </View>

        {/* Content */}
        <View style={styles.content}>

          {/* Title row */}
          <View style={styles.titleRow}>
            <View style={styles.titleBlock}>
              <Text style={styles.goalName}>
                {goal.nombre}
              </Text>
              <Text style={styles.goalDesc}>
                {goal.descripcion}
              </Text>
            </View>
            <View style={styles.titleRight}>
              {pct === 100 && (
                <View style={styles.trophyBadge}>
                  <Text style={styles.trophyIcon}>🏆</Text>
                </View>
              )}
              <Text style={styles.chevron}>›</Text>
            </View>
          </View>

          {/* Progress bar */}
          <View style={styles.progressSection}>
            <View style={styles.progressLabels}>
              <Text style={styles.milestonesLabel}>
                {completedCount}/{totalCount} hitos
              </Text>
              <Text style={[styles.pctLabel, { color: col.main }]}>
                {pct}%
              </Text>
            </View>
            <View style={styles.progressBar}>
              <View
                style={[
                  styles.progressFill,
                  {
                    width: `${pct}%`,
                    backgroundColor: pct === 100 ? '#4ade80' : col.main,
                  },
                ]}
              />
            </View>
          </View>

          {/* Footer row */}
          <View style={styles.footerRow}>
            <View style={styles.dateRow}>
              <Text style={styles.calIcon}>📅</Text>
              <Text style={styles.dateText}>
                {formatDeadline(goal.deadline)}
              </Text>
            </View>
            {deadlineBadge()}
          </View>

        </View>
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  card: {
    borderRadius: 16,
    padding: 16,
    marginBottom: 12,
    backgroundColor: 'rgba(255,255,255,0.88)',
    borderWidth: 1,
    borderColor: 'rgba(14,165,233,0.12)',
    shadowColor: '#0ea5e9',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 10,
    elevation: 3,
  },
  row: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 12,
  },
  iconContainer: {
    width: 44,
    height: 44,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
    flexShrink: 0,
  },
  iconText: {
    fontSize: 20,
    color: 'white',
  },
  content: {
    flex: 1,
  },
  titleRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent: 'space-between',
    gap: 8,
  },
  titleBlock: {
    flex: 1,
  },
  goalName: {
    color: '#0e7490',
    fontWeight: '700',
    fontSize: 15,
  },
  goalDesc: {
    color: '#64748b',
    fontSize: 12,
    marginTop: 2,
  },
  titleRight: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    flexShrink: 0,
  },
  trophyBadge: {
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: '#f0fdf4',
    alignItems: 'center',
    justifyContent: 'center',
  },
  trophyIcon: {
    fontSize: 13,
  },
  chevron: {
    fontSize: 20,
    color: '#cbd5e1',
    lineHeight: 22,
  },
  progressSection: {
    marginTop: 12,
  },
  progressLabels: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 4,
  },
  milestonesLabel: {
    color: '#94a3b8',
    fontSize: 11,
  },
  pctLabel: {
    fontSize: 11,
    fontWeight: '700',
  },
  progressBar: {
    width: '100%',
    height: 8,
    borderRadius: 4,
    backgroundColor: '#f1f5f9',
    overflow: 'hidden',
  },
  progressFill: {
    height: 8,
    borderRadius: 4,
  },
  footerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    marginTop: 8,
  },
  dateRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  calIcon: {
    fontSize: 11,
  },
  dateText: {
    color: '#94a3b8',
    fontSize: 11,
  },
  badgeRed: {
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 20,
    backgroundColor: '#fef2f2',
  },
  badgeRedText: {
    color: '#ef4444',
    fontSize: 11,
    fontWeight: '600',
  },
  badgeOrange: {
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 20,
    backgroundColor: '#fff7ed',
  },
  badgeOrangeText: {
    color: '#f97316',
    fontSize: 11,
    fontWeight: '600',
  },
  badgeDefault: {
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 20,
  },
  badgeDefaultText: {
    fontSize: 11,
    fontWeight: '600',
  },
});