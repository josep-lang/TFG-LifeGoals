import React, { useState } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
} from 'react-native';

export function MilestoneItem({ milestone, onToggle, onDelete }) {
  const [showDelete, setShowDelete] = useState(false);

  return (
    <TouchableOpacity
      onPress={() => setShowDelete(!showDelete)}
      activeOpacity={0.8}
      style={[
        styles.container,
        milestone.completed ? styles.containerCompleted : styles.containerPending,
      ]}
    >
      {/* Checkbox */}
      <TouchableOpacity
        onPress={onToggle}
        hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
        style={styles.checkButton}
      >
        <Text style={milestone.completed ? styles.checkDone : styles.checkPending}>
          {milestone.completed ? '✅' : '⭕'}
        </Text>
      </TouchableOpacity>

      {/* Text */}
      <Text
        style={[
          styles.milestoneText,
          milestone.completed && styles.milestoneTextCompleted,
        ]}
      >
        {milestone.text}
      </Text>

      {/* Delete button — visible al tocar la fila */}
      {showDelete && (
        <TouchableOpacity
          onPress={onDelete}
          style={styles.deleteButton}
          hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
        >
          <Text style={styles.deleteIcon}>🗑</Text>
        </TouchableOpacity>
      )}
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    padding: 12,
    borderRadius: 12,
    borderWidth: 1,
    marginBottom: 6,
  },
  containerPending: {
    backgroundColor: '#f8fafc',
    borderColor: 'rgba(14,165,233,0.1)',
  },
  containerCompleted: {
    backgroundColor: '#f0fdf4',
    borderColor: '#bbf7d0',
  },
  checkButton: {
    flexShrink: 0,
  },
  checkDone: {
    fontSize: 20,
  },
  checkPending: {
    fontSize: 20,
  },
  milestoneText: {
    flex: 1,
    color: '#0e7490',
    fontSize: 14,
  },
  milestoneTextCompleted: {
    color: '#4ade80',
    opacity: 0.75,
    textDecorationLine: 'line-through',
  },
  deleteButton: {
    padding: 4,
    borderRadius: 8,
  },
  deleteIcon: {
    fontSize: 14,
  },
});