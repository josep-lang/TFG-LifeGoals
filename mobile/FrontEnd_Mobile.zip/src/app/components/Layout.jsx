import React, { useState } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  StatusBar,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';
import Sidebar from './Sidebar';
import { ProfileModal } from './ProfileModal';
import { useGoals } from '../context/GoalsContext';

// Iconos simples SVG-free como componentes Text
function MenuIcon() {
  return <Text style={styles.iconText}>☰</Text>;
}
function PlusIcon() {
  return <Text style={styles.iconText}>＋</Text>;
}
function TargetIcon() {
  return <Text style={{ fontSize: 18, color: '#0891b2' }}>◎</Text>;
}

export default function Layout({ children }) {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);
  const { user, setSelectedGoalId } = useGoals();
  const navigation = useNavigation();

  const handleGoHome = () => {
    setSelectedGoalId(null);
    navigation.navigate('Dashboard');
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <StatusBar barStyle="dark-content" backgroundColor="#f0f9ff" />

      <Sidebar open={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      <ProfileModal visible={profileOpen} onClose={() => setProfileOpen(false)} />

      {/* Decorative blobs */}
      <View style={styles.blobTopRight} pointerEvents="none" />
      <View style={styles.blobBottomLeft} pointerEvents="none" />

      {/* Top navbar */}
      <View style={styles.header}>
        <View style={styles.headerLeft}>
          <TouchableOpacity
            onPress={() => setSidebarOpen(true)}
            style={styles.menuButton}
            activeOpacity={0.8}
          >
            <MenuIcon />
          </TouchableOpacity>
          <TouchableOpacity 
            onPress={handleGoHome}
            style={styles.brandContainer}
            activeOpacity={0.7}
          >
            <TargetIcon />
            <Text style={styles.brandText}>Life Goals</Text>
          </TouchableOpacity>
        </View>

        <View style={styles.headerRight}>
          <TouchableOpacity
            onPress={() => navigation.navigate('CreateGoal')}
            style={styles.newGoalButton}
            activeOpacity={0.8}
          >
            <PlusIcon />
            <Text style={styles.newGoalText}>Nueva Meta</Text>
          </TouchableOpacity>

          {user && (
            <TouchableOpacity 
              onPress={() => setProfileOpen(true)}
              style={styles.avatar}
              activeOpacity={0.7}
            >
              <Text style={styles.avatarText}>
                {user.name.charAt(0).toUpperCase()}
              </Text>
            </TouchableOpacity>
          )}
        </View>
      </View>

      {/* Page content */}
      <View style={styles.main}>
        {children}
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: '#f0f9ff',
  },
  blobTopRight: {
    position: 'absolute',
    top: -80,
    right: -80,
    width: 220,
    height: 220,
    borderRadius: 110,
    backgroundColor: 'rgba(14,165,233,0.06)',
  },
  blobBottomLeft: {
    position: 'absolute',
    bottom: -60,
    left: -60,
    width: 180,
    height: 180,
    borderRadius: 90,
    backgroundColor: 'rgba(6,182,212,0.07)',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: 'rgba(255,255,255,0.92)',
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(14,165,233,0.15)',
    shadowColor: '#0ea5e9',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 8,
    elevation: 4,
    zIndex: 30,
  },
  headerLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  menuButton: {
    width: 40,
    height: 40,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#0ea5e9',
  },
  iconText: {
    fontSize: 18,
    color: 'white',
  },
  brandContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  brandText: {
    color: '#0e7490',
    fontWeight: '700',
    fontSize: 17,
  },
  headerRight: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  newGoalButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 12,
    backgroundColor: '#0ea5e9',
  },
  newGoalText: {
    color: 'white',
    fontSize: 14,
    fontWeight: '600',
  },
  avatar: {
    width: 36,
    height: 36,
    borderRadius: 10,
    backgroundColor: '#0891b2',
    alignItems: 'center',
    justifyContent: 'center',
  },
  avatarText: {
    color: 'white',
    fontWeight: '700',
    fontSize: 15,
  },
  main: {
    flex: 1,
    paddingHorizontal: 16,
    paddingVertical: 24,
  },
});