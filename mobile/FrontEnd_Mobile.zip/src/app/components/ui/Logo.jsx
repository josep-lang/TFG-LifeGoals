import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

export function Logo({ size = 80 }) {
  const innerSize = size * 0.7;
  const iconSize = size * 0.4;

  return (
    <View style={[styles.container, { width: size, height: size }]}>
      <View style={[styles.outerCircle, { borderRadius: size / 3, width: size, height: size }]}>
        <View style={[styles.middleCircle, { 
          width: innerSize, 
          height: innerSize, 
          borderRadius: innerSize / 3,
        }]}>
          <Text style={{ fontSize: iconSize }}>🎯</Text>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  outerCircle: {
    backgroundColor: '#0e7490',
    alignItems: 'center',
    justifyContent: 'center',
  },
  middleCircle: {
    backgroundColor: '#0ea5e9',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.3)',
  },
});
