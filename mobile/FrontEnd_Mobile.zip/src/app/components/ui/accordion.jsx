import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, LayoutAnimation, Platform, UIManager } from 'react-native';

// Habilitar LayoutAnimation en Android
if (Platform.OS === 'android' && UIManager.setLayoutAnimationEnabledExperimental) {
  UIManager.setLayoutAnimationEnabledExperimental(true);
}

function Accordion({ children }) {
  return (
    <View style={styles.accordion}>
      {children}
    </View>
  );
}

function AccordionItem({ children, value }) {
  return (
    <View style={styles.accordionItem}>
      {children}
    </View>
  );
}

function AccordionTrigger({ children, isOpen, onPress }) {
  return (
    <TouchableOpacity
      style={styles.trigger}
      onPress={onPress}
      activeOpacity={0.7}
    >
      <Text style={styles.triggerText}>{children}</Text>
      <Text style={[styles.chevron, isOpen && styles.chevronOpen]}>▼</Text>
    </TouchableOpacity>
  );
}

function AccordionContent({ children, isOpen }) {
  if (!isOpen) return null;
  return (
    <View style={styles.content}>
      {children}
    </View>
  );
}

// Componente completo con estado interno
export function AccordionGroup({ items }) {
  const [openIndex, setOpenIndex] = useState(null);

  const handlePress = (index) => {
    LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <Accordion>
      {items.map((item, index) => (
        <AccordionItem key={index} value={String(index)}>
          <AccordionTrigger
            isOpen={openIndex === index}
            onPress={() => handlePress(index)}
          >
            {item.trigger}
          </AccordionTrigger>
          <AccordionContent isOpen={openIndex === index}>
            {item.content}
          </AccordionContent>
        </AccordionItem>
      ))}
    </Accordion>
  );
}

const styles = StyleSheet.create({
  accordion: {
    width: '100%',
  },
  accordionItem: {
    borderBottomWidth: 1,
    borderBottomColor: '#e2e8f0',
  },
  trigger: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 16,
    paddingHorizontal: 4,
  },
  triggerText: {
    flex: 1,
    fontSize: 14,
    fontWeight: '500',
    color: '#0f172a',
  },
  chevron: {
    fontSize: 12,
    color: '#64748b',
    transform: [{ rotate: '0deg' }],
  },
  chevronOpen: {
    transform: [{ rotate: '180deg' }],
  },
  content: {
    paddingBottom: 16,
    paddingHorizontal: 4,
  },
});

export { Accordion, AccordionItem, AccordionTrigger, AccordionContent };